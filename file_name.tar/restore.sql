--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.8 (Ubuntu 11.8-1.pgdg18.04+1)
-- Dumped by pg_dump version 11.8 (Ubuntu 11.8-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE crowdai_development;
--
-- Name: crowdai_development; Type: DATABASE; Schema: -; Owner: nick_nack
--

CREATE DATABASE crowdai_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE crowdai_development OWNER TO nick_nack;

\connect crowdai_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: active_admin_comments; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.active_admin_comments (
    id integer NOT NULL,
    namespace character varying,
    body text,
    resource_id character varying NOT NULL,
    resource_type character varying NOT NULL,
    author_type character varying,
    author_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.active_admin_comments OWNER TO nick_nack;

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.active_admin_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.active_admin_comments_id_seq OWNER TO nick_nack;

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.active_admin_comments_id_seq OWNED BY public.active_admin_comments.id;


--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.active_storage_attachments (
    id bigint NOT NULL,
    name character varying NOT NULL,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    blob_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.active_storage_attachments OWNER TO nick_nack;

--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.active_storage_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.active_storage_attachments_id_seq OWNER TO nick_nack;

--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.active_storage_attachments_id_seq OWNED BY public.active_storage_attachments.id;


--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.active_storage_blobs (
    id bigint NOT NULL,
    key character varying NOT NULL,
    filename character varying NOT NULL,
    content_type character varying,
    metadata text,
    byte_size bigint NOT NULL,
    checksum character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.active_storage_blobs OWNER TO nick_nack;

--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.active_storage_blobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.active_storage_blobs_id_seq OWNER TO nick_nack;

--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.active_storage_blobs_id_seq OWNED BY public.active_storage_blobs.id;


--
-- Name: ahoy_events; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.ahoy_events (
    id bigint NOT NULL,
    visit_id bigint,
    user_id bigint,
    name character varying,
    properties jsonb,
    "time" timestamp without time zone
);


ALTER TABLE public.ahoy_events OWNER TO nick_nack;

--
-- Name: ahoy_events_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.ahoy_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ahoy_events_id_seq OWNER TO nick_nack;

--
-- Name: ahoy_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.ahoy_events_id_seq OWNED BY public.ahoy_events.id;


--
-- Name: ahoy_visits; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.ahoy_visits (
    id bigint NOT NULL,
    visit_token character varying,
    visitor_token character varying,
    user_id bigint,
    ip character varying,
    user_agent text,
    referrer text,
    referring_domain character varying,
    landing_page text,
    browser character varying,
    os character varying,
    device_type character varying,
    country character varying,
    region character varying,
    city character varying,
    latitude double precision,
    longitude double precision,
    utm_source character varying,
    utm_medium character varying,
    utm_term character varying,
    utm_content character varying,
    utm_campaign character varying,
    app_version character varying,
    os_version character varying,
    platform character varying,
    started_at timestamp without time zone
);


ALTER TABLE public.ahoy_visits OWNER TO nick_nack;

--
-- Name: ahoy_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.ahoy_visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ahoy_visits_id_seq OWNER TO nick_nack;

--
-- Name: ahoy_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.ahoy_visits_id_seq OWNED BY public.ahoy_visits.id;


--
-- Name: aicrowd_badges; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.aicrowd_badges (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    badge_type_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    code text,
    badges_event_id bigint,
    image character varying
);


ALTER TABLE public.aicrowd_badges OWNER TO nick_nack;

--
-- Name: aicrowd_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.aicrowd_badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aicrowd_badges_id_seq OWNER TO nick_nack;

--
-- Name: aicrowd_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.aicrowd_badges_id_seq OWNED BY public.aicrowd_badges.id;


--
-- Name: aicrowd_user_badges; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.aicrowd_user_badges (
    id bigint NOT NULL,
    aicrowd_badge_id bigint,
    participant_id bigint,
    custom_fields jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    toast_shown boolean DEFAULT false NOT NULL
);


ALTER TABLE public.aicrowd_user_badges OWNER TO nick_nack;

--
-- Name: aicrowd_user_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.aicrowd_user_badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aicrowd_user_badges_id_seq OWNER TO nick_nack;

--
-- Name: aicrowd_user_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.aicrowd_user_badges_id_seq OWNED BY public.aicrowd_user_badges.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO nick_nack;

--
-- Name: badge_types; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.badge_types (
    id bigint NOT NULL,
    name character varying NOT NULL,
    color_hexcode character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.badge_types OWNER TO nick_nack;

--
-- Name: badge_types_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.badge_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.badge_types_id_seq OWNER TO nick_nack;

--
-- Name: badge_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.badge_types_id_seq OWNED BY public.badge_types.id;


--
-- Name: badges_events; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.badges_events (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.badges_events OWNER TO nick_nack;

--
-- Name: badges_events_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.badges_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.badges_events_id_seq OWNER TO nick_nack;

--
-- Name: badges_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.badges_events_id_seq OWNED BY public.badges_events.id;


--
-- Name: base_leaderboards; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.base_leaderboards (
    id bigint NOT NULL,
    challenge_id bigint,
    challenge_round_id bigint,
    row_num integer,
    previous_row_num integer,
    slug character varying,
    name character varying,
    entries integer,
    score double precision,
    score_secondary double precision,
    media_large character varying,
    media_thumbnail character varying,
    media_content_type character varying,
    description character varying,
    description_markdown character varying,
    leaderboard_type_cd character varying,
    refreshed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    submission_id integer,
    post_challenge boolean DEFAULT false,
    seq integer,
    baseline boolean,
    baseline_comment character varying,
    meta json,
    submitter_type character varying,
    submitter_id bigint,
    meta_challenge_id integer
);


ALTER TABLE public.base_leaderboards OWNER TO nick_nack;

--
-- Name: base_leaderboards_20180809; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.base_leaderboards_20180809 (
    id bigint,
    challenge_id bigint,
    challenge_round_id bigint,
    participant_id bigint,
    row_num integer,
    previous_row_num integer,
    slug character varying,
    name character varying,
    entries integer,
    score double precision,
    score_secondary double precision,
    media_large character varying,
    media_thumbnail character varying,
    media_content_type character varying,
    description character varying,
    description_markdown character varying,
    leaderboard_type_cd character varying,
    refreshed_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    submission_id integer,
    post_challenge boolean
);


ALTER TABLE public.base_leaderboards_20180809 OWNER TO nick_nack;

--
-- Name: base_leaderboards_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.base_leaderboards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.base_leaderboards_id_seq OWNER TO nick_nack;

--
-- Name: base_leaderboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.base_leaderboards_id_seq OWNED BY public.base_leaderboards.id;


--
-- Name: blazer_audits; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.blazer_audits (
    id bigint NOT NULL,
    user_id bigint,
    query_id bigint,
    statement text,
    data_source character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.blazer_audits OWNER TO nick_nack;

--
-- Name: blazer_audits_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.blazer_audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blazer_audits_id_seq OWNER TO nick_nack;

--
-- Name: blazer_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.blazer_audits_id_seq OWNED BY public.blazer_audits.id;


--
-- Name: blazer_checks; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.blazer_checks (
    id bigint NOT NULL,
    creator_id bigint,
    query_id bigint,
    state character varying,
    schedule character varying,
    emails text,
    slack_channels text,
    check_type character varying,
    message text,
    last_run_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blazer_checks OWNER TO nick_nack;

--
-- Name: blazer_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.blazer_checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blazer_checks_id_seq OWNER TO nick_nack;

--
-- Name: blazer_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.blazer_checks_id_seq OWNED BY public.blazer_checks.id;


--
-- Name: blazer_dashboard_queries; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.blazer_dashboard_queries (
    id bigint NOT NULL,
    dashboard_id bigint,
    query_id bigint,
    "position" integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blazer_dashboard_queries OWNER TO nick_nack;

--
-- Name: blazer_dashboard_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.blazer_dashboard_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blazer_dashboard_queries_id_seq OWNER TO nick_nack;

--
-- Name: blazer_dashboard_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.blazer_dashboard_queries_id_seq OWNED BY public.blazer_dashboard_queries.id;


--
-- Name: blazer_dashboards; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.blazer_dashboards (
    id bigint NOT NULL,
    creator_id bigint,
    name text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blazer_dashboards OWNER TO nick_nack;

--
-- Name: blazer_dashboards_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.blazer_dashboards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blazer_dashboards_id_seq OWNER TO nick_nack;

--
-- Name: blazer_dashboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.blazer_dashboards_id_seq OWNED BY public.blazer_dashboards.id;


--
-- Name: blazer_queries; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.blazer_queries (
    id bigint NOT NULL,
    creator_id bigint,
    name character varying,
    description text,
    statement text,
    data_source character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blazer_queries OWNER TO nick_nack;

--
-- Name: blazer_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.blazer_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blazer_queries_id_seq OWNER TO nick_nack;

--
-- Name: blazer_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.blazer_queries_id_seq OWNED BY public.blazer_queries.id;


--
-- Name: blogs; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.blogs (
    id bigint NOT NULL,
    participant_id bigint,
    title character varying,
    body text,
    published boolean,
    vote_count integer,
    view_count integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    seq integer,
    posted_at timestamp without time zone,
    slug character varying
);


ALTER TABLE public.blogs OWNER TO nick_nack;

--
-- Name: blogs_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.blogs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blogs_id_seq OWNER TO nick_nack;

--
-- Name: blogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.blogs_id_seq OWNED BY public.blogs.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO nick_nack;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO nick_nack;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: category_challenges; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.category_challenges (
    id bigint NOT NULL,
    category_id bigint NOT NULL,
    challenge_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.category_challenges OWNER TO nick_nack;

--
-- Name: category_challenges_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.category_challenges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_challenges_id_seq OWNER TO nick_nack;

--
-- Name: category_challenges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.category_challenges_id_seq OWNED BY public.category_challenges.id;


--
-- Name: challenge_call_responses; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_call_responses (
    id bigint NOT NULL,
    challenge_call_id bigint,
    email character varying,
    phone character varying,
    organization character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    challenge_description text,
    contact_name character varying,
    challenge_title character varying,
    motivation text,
    timeline text,
    evaluation_criteria text,
    organizers_bio text,
    other text
);


ALTER TABLE public.challenge_call_responses OWNER TO nick_nack;

--
-- Name: challenge_call_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_call_responses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_call_responses_id_seq OWNER TO nick_nack;

--
-- Name: challenge_call_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_call_responses_id_seq OWNED BY public.challenge_call_responses.id;


--
-- Name: challenge_calls; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_calls (
    id bigint NOT NULL,
    title character varying,
    website character varying,
    closing_date timestamp without time zone,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    slug character varying,
    organizer_id bigint,
    headline character varying,
    acknowledged boolean DEFAULT false NOT NULL
);


ALTER TABLE public.challenge_calls OWNER TO nick_nack;

--
-- Name: challenge_calls_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_calls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_calls_id_seq OWNER TO nick_nack;

--
-- Name: challenge_calls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_calls_id_seq OWNED BY public.challenge_calls.id;


--
-- Name: challenge_participants; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_participants (
    id bigint NOT NULL,
    challenge_id bigint,
    participant_id bigint,
    email character varying,
    name character varying,
    registered boolean DEFAULT false,
    clef_task_id integer,
    clef_eua_file character varying,
    clef_approved boolean DEFAULT false,
    clef_status_cd character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    challenge_rules_accepted_date timestamp without time zone,
    challenge_rules_accepted_version integer,
    challenge_rules_additional_checkbox boolean DEFAULT false
);


ALTER TABLE public.challenge_participants OWNER TO nick_nack;

--
-- Name: challenge_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_participants_id_seq OWNER TO nick_nack;

--
-- Name: challenge_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_participants_id_seq OWNED BY public.challenge_participants.id;


--
-- Name: challenge_partners; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_partners (
    id bigint NOT NULL,
    challenge_id bigint,
    image_file character varying,
    partner_url character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.challenge_partners OWNER TO nick_nack;

--
-- Name: challenge_partners_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_partners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_partners_id_seq OWNER TO nick_nack;

--
-- Name: challenge_partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_partners_id_seq OWNED BY public.challenge_partners.id;


--
-- Name: challenge_problems; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_problems (
    id bigint NOT NULL,
    challenge_id integer,
    problem_id integer,
    weight double precision,
    challenge_round_id integer
);


ALTER TABLE public.challenge_problems OWNER TO nick_nack;

--
-- Name: challenge_problems_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_problems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_problems_id_seq OWNER TO nick_nack;

--
-- Name: challenge_problems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_problems_id_seq OWNED BY public.challenge_problems.id;


--
-- Name: challenges; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenges (
    id integer NOT NULL,
    challenge character varying,
    status_cd character varying DEFAULT 'draft'::character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    tagline character varying,
    perpetual_challenge boolean DEFAULT false,
    answer_file_s3_key character varying,
    page_views integer DEFAULT 0,
    participant_count integer DEFAULT 0,
    submissions_count integer DEFAULT 0,
    slug character varying,
    submission_license character varying DEFAULT 'Please upload your submissions and include a detailed description of the methodology, techniques and insights leveraged with this submission. After the end of the challenge, these comments will be made public, and the submitted code and models will be freely available to other AIcrowd participants. All submitted content will be licensed under Creative Commons (CC).'::character varying,
    api_required boolean DEFAULT false,
    media_on_leaderboard boolean DEFAULT false,
    challenge_client_name character varying,
    online_grading boolean DEFAULT true,
    vote_count integer DEFAULT 0,
    description_markdown text DEFAULT '## Placeholder Content : Please update this by going into Edit Challenge > Overview > Description '::text,
    description text DEFAULT '<h2> Placeholder Content : Please update this by going into Edit Challenge > Overview > Description </h2> '::text,
    evaluation_markdown text,
    evaluation text,
    rules_markdown text,
    rules text,
    prizes_markdown text,
    prizes text,
    resources_markdown text,
    resources text,
    submission_instructions_markdown text,
    submission_instructions text,
    license_markdown text,
    license text,
    dataset_description_markdown text,
    dataset_description text,
    image_file character varying,
    featured_sequence integer DEFAULT 1,
    dynamic_content_flag boolean DEFAULT false,
    dynamic_content text,
    dynamic_content_tab character varying,
    winner_description_markdown text,
    winner_description text,
    winners_tab_active boolean DEFAULT false,
    clef_task_id bigint,
    clef_challenge boolean DEFAULT false,
    submissions_page boolean,
    private_challenge boolean DEFAULT false,
    show_leaderboard boolean DEFAULT true,
    grader_identifier character varying DEFAULT 'AIcrowd_GRADER_POOL'::character varying,
    online_submissions boolean DEFAULT false,
    grader_logs boolean DEFAULT false,
    require_registration boolean DEFAULT false,
    grading_history boolean DEFAULT false,
    post_challenge_submissions boolean DEFAULT false,
    submissions_downloadable boolean DEFAULT false,
    dataset_note_markdown text,
    dataset_note text,
    discussions_visible boolean DEFAULT true,
    require_toc_acceptance boolean DEFAULT false,
    toc_acceptance_text character varying,
    toc_acceptance_instructions text,
    toc_acceptance_instructions_markdown text,
    toc_accordion boolean DEFAULT false,
    dynamic_content_url character varying,
    prize_cash character varying,
    prize_travel integer,
    prize_academic integer,
    prize_misc character varying,
    discourse_category_id integer,
    latest_submission boolean DEFAULT false,
    other_scores_fieldnames character varying,
    teams_allowed boolean DEFAULT true NOT NULL,
    max_team_participants integer DEFAULT 5,
    team_freeze_seconds_before_end integer DEFAULT 604800,
    hidden_challenge boolean DEFAULT false NOT NULL,
    team_freeze_time timestamp without time zone,
    evaluator_type_cd character varying,
    scrollable_overview_tabs boolean DEFAULT true NOT NULL,
    discourse_group_id bigint,
    discourse_group_name character varying,
    meta_challenge boolean,
    practice_flag boolean DEFAULT false NOT NULL,
    banner_file character varying,
    banner_color character varying,
    big_challenge_card_image boolean,
    banner_mobile_file character varying,
    weight double precision DEFAULT 0.0 NOT NULL,
    editors_selection boolean DEFAULT false NOT NULL
);


ALTER TABLE public.challenges OWNER TO nick_nack;

--
-- Name: dataset_file_downloads; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.dataset_file_downloads (
    id integer NOT NULL,
    participant_id integer,
    dataset_file_id integer,
    ip_address character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.dataset_file_downloads OWNER TO nick_nack;

--
-- Name: dataset_files; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.dataset_files (
    id integer NOT NULL,
    seq integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    description character varying,
    challenge_id integer,
    dataset_file_s3_key character varying,
    evaluation boolean DEFAULT false,
    title character varying,
    hosting_location character varying,
    external_url character varying,
    visible boolean DEFAULT true,
    external_file_size character varying,
    file_path text,
    aws_access_key character varying,
    aws_secret_key character varying,
    bucket_name text,
    region character varying
);


ALTER TABLE public.dataset_files OWNER TO nick_nack;

--
-- Name: participant_clef_tasks; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.participant_clef_tasks (
    id bigint NOT NULL,
    participant_id bigint,
    clef_task_id bigint,
    approved boolean DEFAULT false,
    eua_file character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status_cd character varying
);


ALTER TABLE public.participant_clef_tasks OWNER TO nick_nack;

--
-- Name: submissions; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.submissions (
    id integer NOT NULL,
    challenge_id integer,
    participant_id integer,
    score double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    description text,
    score_secondary double precision,
    grading_message character varying,
    grading_status_cd character varying DEFAULT 'ready'::character varying,
    description_markdown text,
    vote_count integer DEFAULT 0,
    post_challenge boolean DEFAULT false,
    api character varying,
    media_large character varying,
    media_thumbnail character varying,
    media_content_type character varying,
    challenge_round_id integer,
    meta json DEFAULT '{}'::json,
    short_url character varying,
    clef_method_description text,
    clef_retrieval_type character varying,
    clef_run_type character varying,
    clef_primary_run boolean DEFAULT false,
    clef_other_info text,
    clef_additional text,
    online_submission boolean DEFAULT false,
    score_display double precision,
    score_secondary_display double precision,
    baseline boolean DEFAULT false,
    baseline_comment character varying,
    meta_challenge_id integer,
    submission_link character varying
);


ALTER TABLE public.submissions OWNER TO nick_nack;

--
-- Name: votes; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.votes (
    id integer NOT NULL,
    votable_id integer NOT NULL,
    votable_type character varying NOT NULL,
    participant_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.votes OWNER TO nick_nack;

--
-- Name: challenge_registrations; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.challenge_registrations AS
 SELECT row_number() OVER () AS id,
    x.challenge_id,
    x.participant_id,
    x.registration_type,
    x.clef_task_id
   FROM ( SELECT s.challenge_id,
            s.participant_id,
            'submission'::text AS registration_type,
            NULL::integer AS clef_task_id
           FROM public.submissions s
        UNION
         SELECT s.votable_id,
            s.participant_id,
            'heart'::text AS registration_type,
            NULL::integer AS clef_task_id
           FROM public.votes s
          WHERE ((s.votable_type)::text = 'Challenge'::text)
        UNION
         SELECT df.challenge_id,
            dfd.participant_id,
            'dataset_download'::text AS text,
            NULL::integer AS clef_task_id
           FROM public.dataset_file_downloads dfd,
            public.dataset_files df
          WHERE (dfd.dataset_file_id = df.id)
        UNION
         SELECT c.id,
            pc.participant_id,
            'clef_task'::text AS registration_type,
            pc.clef_task_id
           FROM public.participant_clef_tasks pc,
            public.challenges c
          WHERE (c.clef_task_id = pc.clef_task_id)) x;


ALTER TABLE public.challenge_registrations OWNER TO nick_nack;

--
-- Name: challenge_rounds; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_rounds (
    id bigint NOT NULL,
    challenge_id bigint,
    challenge_round character varying,
    active boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    submission_limit integer DEFAULT 5,
    submission_limit_period_cd character varying DEFAULT 'day'::character varying,
    start_dttm timestamp without time zone,
    end_dttm timestamp without time zone,
    minimum_score double precision DEFAULT 0.0,
    minimum_score_secondary double precision DEFAULT 0.0,
    ranking_window integer DEFAULT 96,
    ranking_highlight integer DEFAULT 3,
    score_precision integer DEFAULT 3,
    score_secondary_precision integer DEFAULT 3,
    leaderboard_note_markdown text,
    leaderboard_note text,
    failed_submissions integer DEFAULT 0,
    parallel_submissions integer DEFAULT 0 NOT NULL,
    score_title character varying DEFAULT 'Score'::character varying NOT NULL,
    score_secondary_title character varying DEFAULT 'Secondary Score'::character varying NOT NULL,
    primary_sort_order_cd character varying DEFAULT 'ascending'::character varying NOT NULL,
    secondary_sort_order_cd character varying DEFAULT 'not_used'::character varying NOT NULL,
    calculated_permanent boolean DEFAULT false NOT NULL,
    assigned_permanent_badge boolean DEFAULT false NOT NULL
);


ALTER TABLE public.challenge_rounds OWNER TO nick_nack;

--
-- Name: challenge_round_views; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.challenge_round_views AS
 SELECT cr.id,
    cr.challenge_round,
    cr.row_num,
    cr.active,
    cr.challenge_id,
    cr.start_dttm,
    cr.end_dttm,
    cr.submission_limit,
    cr.submission_limit_period_cd,
    cr.failed_submissions,
    cr.minimum_score,
    cr.minimum_score_secondary
   FROM ( SELECT r1.id,
            r1.challenge_id,
            r1.challenge_round,
            r1.active,
            r1.created_at,
            r1.updated_at,
            r1.submission_limit,
            r1.submission_limit_period_cd,
            r1.start_dttm,
            r1.end_dttm,
            r1.minimum_score,
            r1.minimum_score_secondary,
            r1.ranking_window,
            r1.ranking_highlight,
            r1.score_precision,
            r1.score_secondary_precision,
            r1.leaderboard_note_markdown,
            r1.leaderboard_note,
            r1.failed_submissions,
            row_number() OVER (PARTITION BY r1.challenge_id ORDER BY r1.challenge_id, r1.start_dttm) AS row_num
           FROM public.challenge_rounds r1) cr;


ALTER TABLE public.challenge_round_views OWNER TO nick_nack;

--
-- Name: challenge_round_summaries; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.challenge_round_summaries AS
 SELECT cr.id,
    cr.challenge_round,
    cr.row_num,
    acr.row_num AS active_row_num,
        CASE
            WHEN (cr.row_num < acr.row_num) THEN 'history'::text
            WHEN (cr.row_num = acr.row_num) THEN 'current'::text
            WHEN (cr.row_num > acr.row_num) THEN 'future'::text
            ELSE NULL::text
        END AS round_status_cd,
    cr.active,
    cr.challenge_id,
    cr.start_dttm,
    cr.end_dttm,
    cr.submission_limit,
    cr.submission_limit_period_cd,
    cr.failed_submissions,
    cr.minimum_score,
    cr.minimum_score_secondary,
    c.status_cd
   FROM public.challenge_round_views cr,
    public.challenge_round_views acr,
    public.challenges c
  WHERE ((c.id = cr.challenge_id) AND (c.id = acr.challenge_id) AND (acr.active IS TRUE));


ALTER TABLE public.challenge_round_summaries OWNER TO nick_nack;

--
-- Name: challenge_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_rounds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_rounds_id_seq OWNER TO nick_nack;

--
-- Name: challenge_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_rounds_id_seq OWNED BY public.challenge_rounds.id;


--
-- Name: challenge_rules; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenge_rules (
    id bigint NOT NULL,
    challenge_id bigint,
    terms text DEFAULT '<h2> Placeholder Content : Please update this by going into Edit Challenge > Rules > Set Challenge Rules </h2> '::text,
    terms_markdown text DEFAULT '## Placeholder Content : Please update this by going into Edit Challenge > Rules > Set Challenge Rules '::text,
    instructions text,
    instructions_markdown text,
    has_additional_checkbox boolean DEFAULT false,
    additional_checkbox_text character varying,
    version integer DEFAULT 1,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    additional_checkbox_text_markdown character varying
);


ALTER TABLE public.challenge_rules OWNER TO nick_nack;

--
-- Name: challenge_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenge_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_rules_id_seq OWNER TO nick_nack;

--
-- Name: challenge_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenge_rules_id_seq OWNED BY public.challenge_rules.id;


--
-- Name: participants; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.participants (
    id integer NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    confirmation_token character varying,
    confirmed_at timestamp without time zone,
    confirmation_sent_at timestamp without time zone,
    failed_attempts integer DEFAULT 0 NOT NULL,
    unlock_token character varying,
    locked_at timestamp without time zone,
    admin boolean DEFAULT false,
    verified boolean DEFAULT false,
    verification_date date,
    timezone character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    unconfirmed_email character varying,
    name character varying,
    email_public boolean DEFAULT false,
    bio text,
    website character varying,
    github character varying,
    linkedin character varying,
    twitter character varying,
    account_disabled boolean DEFAULT false,
    account_disabled_reason text,
    account_disabled_dttm timestamp without time zone,
    slug character varying,
    api_key character varying,
    image_file character varying,
    affiliation character varying,
    country_cd character varying,
    address text,
    city character varying,
    first_name character varying,
    last_name character varying,
    clef_email boolean DEFAULT false,
    provider character varying,
    uid character varying,
    participation_terms_accepted_date timestamp without time zone,
    participation_terms_accepted_version integer,
    agreed_to_terms_of_use_and_privacy boolean DEFAULT true,
    agreed_to_marketing boolean DEFAULT true,
    rating double precision,
    temporary_rating double precision,
    variation double precision,
    temporary_variation double precision,
    ranking integer DEFAULT '-1'::integer NOT NULL,
    ranking_change integer DEFAULT 0 NOT NULL,
    agreed_to_organizers_newsletter boolean DEFAULT true NOT NULL,
    fixed_rating double precision
);


ALTER TABLE public.participants OWNER TO nick_nack;

--
-- Name: challenge_stats; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.challenge_stats AS
 SELECT row_number() OVER () AS id,
    c.id AS challenge_id,
    c.challenge,
    r.id AS challenge_round_id,
    r.challenge_round,
    r.start_dttm,
    r.end_dttm,
    (r.end_dttm - r.start_dttm) AS duration,
    ( SELECT count(s.id) AS count
           FROM public.submissions s
          WHERE (s.challenge_id = c.id)) AS submissions,
    ( SELECT count(p.id) AS count
           FROM public.participants p
          WHERE (p.id IN ( SELECT s1.participant_id
                   FROM public.submissions s1
                  WHERE (s1.challenge_id = c.id)))) AS participants
   FROM public.challenges c,
    public.challenge_rounds r
  WHERE (r.challenge_id = c.id)
  ORDER BY (row_number() OVER ()), c.challenge;


ALTER TABLE public.challenge_stats OWNER TO nick_nack;

--
-- Name: challenges_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenges_id_seq OWNER TO nick_nack;

--
-- Name: challenges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenges_id_seq OWNED BY public.challenges.id;


--
-- Name: challenges_organizers; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.challenges_organizers (
    id bigint NOT NULL,
    challenge_id bigint NOT NULL,
    organizer_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.challenges_organizers OWNER TO nick_nack;

--
-- Name: challenges_organizers_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.challenges_organizers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenges_organizers_id_seq OWNER TO nick_nack;

--
-- Name: challenges_organizers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.challenges_organizers_id_seq OWNED BY public.challenges_organizers.id;


--
-- Name: ckeditor_assets; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.ckeditor_assets (
    id bigint NOT NULL,
    data_file_name character varying NOT NULL,
    data_content_type character varying,
    data_file_size integer,
    type character varying(30),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ckeditor_assets OWNER TO nick_nack;

--
-- Name: ckeditor_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.ckeditor_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ckeditor_assets_id_seq OWNER TO nick_nack;

--
-- Name: ckeditor_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.ckeditor_assets_id_seq OWNED BY public.ckeditor_assets.id;


--
-- Name: clef_tasks; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.clef_tasks (
    id bigint NOT NULL,
    organizer_id bigint,
    task character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    eua_file character varying,
    use_challenge_dataset_files boolean DEFAULT false NOT NULL
);


ALTER TABLE public.clef_tasks OWNER TO nick_nack;

--
-- Name: clef_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.clef_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clef_tasks_id_seq OWNER TO nick_nack;

--
-- Name: clef_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.clef_tasks_id_seq OWNED BY public.clef_tasks.id;


--
-- Name: dataset_file_downloads_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.dataset_file_downloads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_file_downloads_id_seq OWNER TO nick_nack;

--
-- Name: dataset_file_downloads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.dataset_file_downloads_id_seq OWNED BY public.dataset_file_downloads.id;


--
-- Name: dataset_files_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.dataset_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_files_id_seq OWNER TO nick_nack;

--
-- Name: dataset_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.dataset_files_id_seq OWNED BY public.dataset_files.id;


--
-- Name: dataset_folders; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.dataset_folders (
    id bigint NOT NULL,
    title text NOT NULL,
    description text,
    directory_path text NOT NULL,
    aws_access_key character varying NOT NULL,
    aws_secret_key character varying NOT NULL,
    bucket_name text NOT NULL,
    region character varying NOT NULL,
    visible boolean DEFAULT true NOT NULL,
    evaluation boolean DEFAULT false NOT NULL,
    challenge_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    aws_endpoint character varying DEFAULT 'https://s3.amazonaws.com/'::character varying
);


ALTER TABLE public.dataset_folders OWNER TO nick_nack;

--
-- Name: dataset_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.dataset_folders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_folders_id_seq OWNER TO nick_nack;

--
-- Name: dataset_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.dataset_folders_id_seq OWNED BY public.dataset_folders.id;


--
-- Name: discourse_user_badges_meta; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.discourse_user_badges_meta (
    id bigint NOT NULL,
    previous_id integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.discourse_user_badges_meta OWNER TO nick_nack;

--
-- Name: discourse_user_badges_meta_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.discourse_user_badges_meta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discourse_user_badges_meta_id_seq OWNER TO nick_nack;

--
-- Name: discourse_user_badges_meta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.discourse_user_badges_meta_id_seq OWNED BY public.discourse_user_badges_meta.id;


--
-- Name: disentanglement_leaderboards; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.disentanglement_leaderboards (
    id bigint NOT NULL,
    challenge_id bigint,
    challenge_round_id bigint,
    participant_id bigint,
    row_num integer,
    previous_row_num integer,
    slug character varying,
    name character varying,
    entries integer,
    score double precision,
    score_secondary double precision,
    media_large character varying,
    media_thumbnail character varying,
    media_content_type character varying,
    description character varying,
    description_markdown character varying,
    leaderboard_type_cd character varying,
    refreshed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    submission_id integer,
    post_challenge boolean DEFAULT false,
    seq integer,
    baseline boolean,
    baseline_comment character varying,
    meta json,
    extra_score1 double precision,
    extra_score2 double precision,
    extra_score3 double precision,
    extra_score4 double precision,
    extra_score5 double precision,
    avg_rank double precision
);


ALTER TABLE public.disentanglement_leaderboards OWNER TO nick_nack;

--
-- Name: disentanglement_leaderboards_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.disentanglement_leaderboards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.disentanglement_leaderboards_id_seq OWNER TO nick_nack;

--
-- Name: disentanglement_leaderboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.disentanglement_leaderboards_id_seq OWNED BY public.disentanglement_leaderboards.id;


--
-- Name: email_invitations; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.email_invitations (
    id bigint NOT NULL,
    invitor_id bigint NOT NULL,
    email public.citext NOT NULL,
    token public.citext NOT NULL,
    claimant_id bigint,
    claimed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.email_invitations OWNER TO nick_nack;

--
-- Name: email_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.email_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_invitations_id_seq OWNER TO nick_nack;

--
-- Name: email_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.email_invitations_id_seq OWNED BY public.email_invitations.id;


--
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.email_preferences (
    id integer NOT NULL,
    participant_id integer,
    newsletter boolean DEFAULT true,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    challenges_followed boolean DEFAULT true,
    mentions boolean DEFAULT true,
    email_frequency_cd character varying DEFAULT 'daily'::character varying
);


ALTER TABLE public.email_preferences OWNER TO nick_nack;

--
-- Name: email_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.email_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_preferences_id_seq OWNER TO nick_nack;

--
-- Name: email_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.email_preferences_id_seq OWNED BY public.email_preferences.id;


--
-- Name: email_preferences_tokens; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.email_preferences_tokens (
    id bigint NOT NULL,
    participant_id bigint,
    email_preferences_token character varying,
    token_expiration_dttm timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.email_preferences_tokens OWNER TO nick_nack;

--
-- Name: email_preferences_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.email_preferences_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_preferences_tokens_id_seq OWNER TO nick_nack;

--
-- Name: email_preferences_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.email_preferences_tokens_id_seq OWNED BY public.email_preferences_tokens.id;


--
-- Name: follows; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.follows (
    id integer NOT NULL,
    followable_id integer NOT NULL,
    followable_type character varying NOT NULL,
    participant_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.follows OWNER TO nick_nack;

--
-- Name: follows_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.follows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.follows_id_seq OWNER TO nick_nack;

--
-- Name: follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.follows_id_seq OWNED BY public.follows.id;


--
-- Name: friendly_id_slugs; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.friendly_id_slugs (
    id integer NOT NULL,
    slug character varying NOT NULL,
    sluggable_id integer NOT NULL,
    sluggable_type character varying(50),
    scope character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.friendly_id_slugs OWNER TO nick_nack;

--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.friendly_id_slugs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friendly_id_slugs_id_seq OWNER TO nick_nack;

--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.friendly_id_slugs_id_seq OWNED BY public.friendly_id_slugs.id;


--
-- Name: invitations; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.invitations (
    id bigint NOT NULL,
    challenge_id bigint,
    participant_id bigint,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    invitee_name character varying
);


ALTER TABLE public.invitations OWNER TO nick_nack;

--
-- Name: invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invitations_id_seq OWNER TO nick_nack;

--
-- Name: invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.invitations_id_seq OWNED BY public.invitations.id;


--
-- Name: job_postings; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.job_postings (
    id bigint NOT NULL,
    title character varying,
    organisation character varying,
    contact_name character varying,
    contact_email character varying,
    contact_phone character varying,
    posting_date date,
    closing_date date,
    status_cd character varying,
    description text,
    remote boolean DEFAULT true,
    location character varying,
    country character varying,
    page_views integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    job_url character varying,
    slug character varying
);


ALTER TABLE public.job_postings OWNER TO nick_nack;

--
-- Name: job_postings_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.job_postings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_postings_id_seq OWNER TO nick_nack;

--
-- Name: job_postings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.job_postings_id_seq OWNED BY public.job_postings.id;


--
-- Name: leaderboards; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.leaderboards AS
 SELECT base_leaderboards.id,
    base_leaderboards.challenge_id,
    base_leaderboards.challenge_round_id,
    base_leaderboards.row_num,
    base_leaderboards.previous_row_num,
    base_leaderboards.slug,
    base_leaderboards.name,
    base_leaderboards.entries,
    base_leaderboards.score,
    base_leaderboards.score_secondary,
    base_leaderboards.media_large,
    base_leaderboards.media_thumbnail,
    base_leaderboards.media_content_type,
    base_leaderboards.description,
    base_leaderboards.description_markdown,
    base_leaderboards.leaderboard_type_cd,
    base_leaderboards.refreshed_at,
    base_leaderboards.created_at,
    base_leaderboards.updated_at,
    base_leaderboards.submission_id,
    base_leaderboards.post_challenge,
    base_leaderboards.seq,
    base_leaderboards.baseline,
    base_leaderboards.baseline_comment,
    base_leaderboards.meta,
    base_leaderboards.submitter_type,
    base_leaderboards.submitter_id,
    base_leaderboards.meta_challenge_id
   FROM public.base_leaderboards
  WHERE ((base_leaderboards.leaderboard_type_cd)::text = 'leaderboard'::text);


ALTER TABLE public.leaderboards OWNER TO nick_nack;

--
-- Name: mandrill_messages; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.mandrill_messages (
    id bigint NOT NULL,
    res jsonb,
    message jsonb,
    meta jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    participant_id integer
);


ALTER TABLE public.mandrill_messages OWNER TO nick_nack;

--
-- Name: mandrill_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.mandrill_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mandrill_messages_id_seq OWNER TO nick_nack;

--
-- Name: mandrill_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.mandrill_messages_id_seq OWNED BY public.mandrill_messages.id;


--
-- Name: migration_mappings; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.migration_mappings (
    id bigint NOT NULL,
    source_type character varying,
    source_id integer,
    crowdai_participant_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.migration_mappings OWNER TO nick_nack;

--
-- Name: migration_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.migration_mappings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_mappings_id_seq OWNER TO nick_nack;

--
-- Name: migration_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.migration_mappings_id_seq OWNED BY public.migration_mappings.id;


--
-- Name: newsletter_emails; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.newsletter_emails (
    id bigint NOT NULL,
    bcc text DEFAULT ''::text NOT NULL,
    cc text DEFAULT ''::text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    pending boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    participant_id bigint,
    challenge_id bigint,
    decline_reason text
);


ALTER TABLE public.newsletter_emails OWNER TO nick_nack;

--
-- Name: newsletter_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.newsletter_emails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.newsletter_emails_id_seq OWNER TO nick_nack;

--
-- Name: newsletter_emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.newsletter_emails_id_seq OWNED BY public.newsletter_emails.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    participant_id bigint,
    notification_type character varying,
    notifiable_type character varying,
    notifiable_id bigint,
    read_at timestamp without time zone,
    is_new boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    message character varying,
    thumbnail_url character varying,
    notification_url character varying
);


ALTER TABLE public.notifications OWNER TO nick_nack;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO nick_nack;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: oauth_access_grants; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.oauth_access_grants (
    id bigint NOT NULL,
    resource_owner_id integer NOT NULL,
    application_id bigint NOT NULL,
    token character varying NOT NULL,
    expires_in integer NOT NULL,
    redirect_uri text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    revoked_at timestamp without time zone,
    scopes character varying
);


ALTER TABLE public.oauth_access_grants OWNER TO nick_nack;

--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.oauth_access_grants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_access_grants_id_seq OWNER TO nick_nack;

--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.oauth_access_grants_id_seq OWNED BY public.oauth_access_grants.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.oauth_access_tokens (
    id bigint NOT NULL,
    resource_owner_id integer,
    application_id bigint,
    token character varying NOT NULL,
    refresh_token character varying,
    expires_in integer,
    revoked_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    scopes character varying,
    previous_refresh_token character varying DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.oauth_access_tokens OWNER TO nick_nack;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_access_tokens_id_seq OWNER TO nick_nack;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_applications; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.oauth_applications (
    id bigint NOT NULL,
    name character varying NOT NULL,
    uid character varying NOT NULL,
    secret character varying NOT NULL,
    redirect_uri text NOT NULL,
    scopes character varying DEFAULT ''::character varying NOT NULL,
    confidential boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.oauth_applications OWNER TO nick_nack;

--
-- Name: oauth_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.oauth_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_applications_id_seq OWNER TO nick_nack;

--
-- Name: oauth_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.oauth_applications_id_seq OWNED BY public.oauth_applications.id;


--
-- Name: ongoing_leaderboards; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.ongoing_leaderboards AS
 SELECT base_leaderboards.id,
    base_leaderboards.challenge_id,
    base_leaderboards.challenge_round_id,
    base_leaderboards.row_num,
    base_leaderboards.previous_row_num,
    base_leaderboards.slug,
    base_leaderboards.name,
    base_leaderboards.entries,
    base_leaderboards.score,
    base_leaderboards.score_secondary,
    base_leaderboards.media_large,
    base_leaderboards.media_thumbnail,
    base_leaderboards.media_content_type,
    base_leaderboards.description,
    base_leaderboards.description_markdown,
    base_leaderboards.leaderboard_type_cd,
    base_leaderboards.refreshed_at,
    base_leaderboards.created_at,
    base_leaderboards.updated_at,
    base_leaderboards.submission_id,
    base_leaderboards.post_challenge,
    base_leaderboards.seq,
    base_leaderboards.baseline,
    base_leaderboards.baseline_comment,
    base_leaderboards.meta,
    base_leaderboards.submitter_type,
    base_leaderboards.submitter_id,
    base_leaderboards.meta_challenge_id
   FROM public.base_leaderboards
  WHERE ((base_leaderboards.leaderboard_type_cd)::text = 'ongoing'::text);


ALTER TABLE public.ongoing_leaderboards OWNER TO nick_nack;

--
-- Name: organizer_applications; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.organizer_applications (
    id integer NOT NULL,
    contact_name character varying,
    email character varying,
    phone character varying,
    organization character varying,
    organization_description character varying,
    challenge_description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organizer_applications OWNER TO nick_nack;

--
-- Name: organizer_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.organizer_applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizer_applications_id_seq OWNER TO nick_nack;

--
-- Name: organizer_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.organizer_applications_id_seq OWNED BY public.organizer_applications.id;


--
-- Name: organizers; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.organizers (
    id integer NOT NULL,
    organizer character varying,
    address text,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    approved boolean DEFAULT false,
    slug character varying,
    image_file character varying,
    tagline character varying,
    challenge_proposal character varying,
    api_key character varying,
    clef_organizer boolean DEFAULT false
);


ALTER TABLE public.organizers OWNER TO nick_nack;

--
-- Name: organizers_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.organizers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizers_id_seq OWNER TO nick_nack;

--
-- Name: organizers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.organizers_id_seq OWNED BY public.organizers.id;


--
-- Name: participant_challenge_counts; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.participant_challenge_counts AS
 SELECT row_number() OVER () AS row_number,
    y.challenge_id,
    y.participant_id,
    y.registration_type
   FROM ( SELECT DISTINCT x.challenge_id,
            x.participant_id,
            x.registration_type
           FROM ( SELECT s.challenge_id,
                    s.participant_id,
                    'submission'::text AS registration_type
                   FROM public.submissions s
                UNION
                 SELECT s.votable_id,
                    s.participant_id,
                    'heart'::text AS registration_type
                   FROM public.votes s
                  WHERE ((s.votable_type)::text = 'Challenge'::text)
                UNION
                 SELECT df.challenge_id,
                    dfd.participant_id,
                    'dataset_download'::text AS text
                   FROM public.dataset_file_downloads dfd,
                    public.dataset_files df
                  WHERE (dfd.dataset_file_id = df.id)) x
          ORDER BY x.challenge_id, x.participant_id) y;


ALTER TABLE public.participant_challenge_counts OWNER TO nick_nack;

--
-- Name: participant_challenges; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.participant_challenges AS
 SELECT DISTINCT p.id,
    cr.challenge_id,
    cr.participant_id,
    c.status_cd,
    c.challenge,
    c.private_challenge,
    c.description,
    c.rules,
    c.prizes,
    c.resources,
    c.tagline,
    c.image_file,
    c.submissions_count,
    c.participant_count,
    c.page_views,
    p.name,
    p.email,
    p.bio,
    p.github,
    p.linkedin,
    p.twitter
   FROM public.participants p,
    public.challenges c,
    public.challenge_registrations cr
  WHERE ((cr.participant_id = p.id) AND (cr.challenge_id = c.id));


ALTER TABLE public.participant_challenges OWNER TO nick_nack;

--
-- Name: participant_clef_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.participant_clef_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participant_clef_tasks_id_seq OWNER TO nick_nack;

--
-- Name: participant_clef_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.participant_clef_tasks_id_seq OWNED BY public.participant_clef_tasks.id;


--
-- Name: participant_organizers; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.participant_organizers (
    id bigint NOT NULL,
    participant_id bigint,
    organizer_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.participant_organizers OWNER TO nick_nack;

--
-- Name: participant_organizers_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.participant_organizers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participant_organizers_id_seq OWNER TO nick_nack;

--
-- Name: participant_organizers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.participant_organizers_id_seq OWNED BY public.participant_organizers.id;


--
-- Name: participant_sign_ups; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.participant_sign_ups AS
 SELECT row_number() OVER () AS id,
    count(participants.id) AS count,
    (date_part('month'::text, participants.created_at))::integer AS mnth,
    (date_part('year'::text, participants.created_at))::integer AS yr
   FROM public.participants
  GROUP BY ((date_part('month'::text, participants.created_at))::integer), ((date_part('year'::text, participants.created_at))::integer)
  ORDER BY ((date_part('year'::text, participants.created_at))::integer), ((date_part('month'::text, participants.created_at))::integer);


ALTER TABLE public.participant_sign_ups OWNER TO nick_nack;

--
-- Name: submission_files; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.submission_files (
    id integer NOT NULL,
    submission_id integer,
    seq integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    submission_file_s3_key character varying,
    leaderboard_video boolean DEFAULT false,
    submission_type text
);


ALTER TABLE public.submission_files OWNER TO nick_nack;

--
-- Name: participant_submissions; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.participant_submissions AS
 SELECT s.id,
    s.challenge_id,
    s.participant_id,
    p.name,
    s.grading_status_cd,
    s.post_challenge,
    s.score,
    s.score_secondary,
    count(f.*) AS files,
    s.created_at
   FROM public.participants p,
    (public.submissions s
     LEFT JOIN public.submission_files f ON ((f.submission_id = s.id)))
  WHERE (s.participant_id = p.id)
  GROUP BY s.id, s.challenge_id, s.participant_id, p.name, s.grading_status_cd, s.post_challenge, s.score, s.score_secondary, s.created_at
  ORDER BY s.created_at DESC;


ALTER TABLE public.participant_submissions OWNER TO nick_nack;

--
-- Name: participants_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participants_id_seq OWNER TO nick_nack;

--
-- Name: participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.participants_id_seq OWNED BY public.participants.id;


--
-- Name: participation_terms; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.participation_terms (
    id bigint NOT NULL,
    terms text,
    instructions text,
    instructions_markdown text,
    version integer DEFAULT 1,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.participation_terms OWNER TO nick_nack;

--
-- Name: participation_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.participation_terms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participation_terms_id_seq OWNER TO nick_nack;

--
-- Name: participation_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.participation_terms_id_seq OWNED BY public.participation_terms.id;


--
-- Name: partners; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.partners (
    id bigint NOT NULL,
    organizer_id bigint,
    image_file character varying,
    visible boolean DEFAULT false,
    seq integer DEFAULT 0,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying
);


ALTER TABLE public.partners OWNER TO nick_nack;

--
-- Name: partners_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.partners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.partners_id_seq OWNER TO nick_nack;

--
-- Name: partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.partners_id_seq OWNED BY public.partners.id;


--
-- Name: previous_leaderboards; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.previous_leaderboards AS
 SELECT base_leaderboards.id,
    base_leaderboards.challenge_id,
    base_leaderboards.challenge_round_id,
    base_leaderboards.row_num,
    base_leaderboards.previous_row_num,
    base_leaderboards.slug,
    base_leaderboards.name,
    base_leaderboards.entries,
    base_leaderboards.score,
    base_leaderboards.score_secondary,
    base_leaderboards.media_large,
    base_leaderboards.media_thumbnail,
    base_leaderboards.media_content_type,
    base_leaderboards.description,
    base_leaderboards.description_markdown,
    base_leaderboards.leaderboard_type_cd,
    base_leaderboards.refreshed_at,
    base_leaderboards.created_at,
    base_leaderboards.updated_at,
    base_leaderboards.submission_id,
    base_leaderboards.post_challenge,
    base_leaderboards.seq,
    base_leaderboards.baseline,
    base_leaderboards.baseline_comment,
    base_leaderboards.meta,
    base_leaderboards.submitter_type,
    base_leaderboards.submitter_id,
    base_leaderboards.meta_challenge_id
   FROM public.base_leaderboards
  WHERE ((base_leaderboards.leaderboard_type_cd)::text = 'previous'::text);


ALTER TABLE public.previous_leaderboards OWNER TO nick_nack;

--
-- Name: previous_ongoing_leaderboards; Type: VIEW; Schema: public; Owner: nick_nack
--

CREATE VIEW public.previous_ongoing_leaderboards AS
 SELECT base_leaderboards.id,
    base_leaderboards.challenge_id,
    base_leaderboards.challenge_round_id,
    base_leaderboards.row_num,
    base_leaderboards.previous_row_num,
    base_leaderboards.slug,
    base_leaderboards.name,
    base_leaderboards.entries,
    base_leaderboards.score,
    base_leaderboards.score_secondary,
    base_leaderboards.media_large,
    base_leaderboards.media_thumbnail,
    base_leaderboards.media_content_type,
    base_leaderboards.description,
    base_leaderboards.description_markdown,
    base_leaderboards.leaderboard_type_cd,
    base_leaderboards.refreshed_at,
    base_leaderboards.created_at,
    base_leaderboards.updated_at,
    base_leaderboards.submission_id,
    base_leaderboards.post_challenge,
    base_leaderboards.seq,
    base_leaderboards.baseline,
    base_leaderboards.baseline_comment,
    base_leaderboards.meta,
    base_leaderboards.submitter_type,
    base_leaderboards.submitter_id,
    base_leaderboards.meta_challenge_id
   FROM public.base_leaderboards
  WHERE ((base_leaderboards.leaderboard_type_cd)::text = 'previous_ongoing'::text);


ALTER TABLE public.previous_ongoing_leaderboards OWNER TO nick_nack;

--
-- Name: reserved_userhandles; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.reserved_userhandles (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.reserved_userhandles OWNER TO nick_nack;

--
-- Name: reserved_userhandles_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.reserved_userhandles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reserved_userhandles_id_seq OWNER TO nick_nack;

--
-- Name: reserved_userhandles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.reserved_userhandles_id_seq OWNED BY public.reserved_userhandles.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO nick_nack;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    jobs_visible boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    banner_text text DEFAULT 'We are Hiring!'::character varying,
    banner_color character varying DEFAULT '#F0524D'::character varying,
    enable_banner boolean DEFAULT false,
    footer_text text,
    enable_footer boolean DEFAULT false
);


ALTER TABLE public.settings OWNER TO nick_nack;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO nick_nack;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: submission_file_definitions; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.submission_file_definitions (
    id integer NOT NULL,
    challenge_id integer,
    seq integer,
    submission_file_description character varying,
    filetype_cd character varying,
    file_required boolean DEFAULT false,
    submission_file_help_text text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.submission_file_definitions OWNER TO nick_nack;

--
-- Name: submission_file_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.submission_file_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submission_file_definitions_id_seq OWNER TO nick_nack;

--
-- Name: submission_file_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.submission_file_definitions_id_seq OWNED BY public.submission_file_definitions.id;


--
-- Name: submission_files_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.submission_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submission_files_id_seq OWNER TO nick_nack;

--
-- Name: submission_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.submission_files_id_seq OWNED BY public.submission_files.id;


--
-- Name: submission_grades; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.submission_grades (
    id integer NOT NULL,
    submission_id integer,
    grading_status_cd character varying,
    grading_message character varying,
    grading_factor double precision,
    score double precision,
    score_secondary double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    slug character varying
);


ALTER TABLE public.submission_grades OWNER TO nick_nack;

--
-- Name: submission_grades_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.submission_grades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submission_grades_id_seq OWNER TO nick_nack;

--
-- Name: submission_grades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.submission_grades_id_seq OWNED BY public.submission_grades.id;


--
-- Name: submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submissions_id_seq OWNER TO nick_nack;

--
-- Name: submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.submissions_id_seq OWNED BY public.submissions.id;


--
-- Name: success_stories; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.success_stories (
    id bigint NOT NULL,
    title character varying,
    byline text,
    html_content text,
    published boolean,
    posted_at timestamp without time zone,
    seq integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    slug character varying,
    image_file character varying
);


ALTER TABLE public.success_stories OWNER TO nick_nack;

--
-- Name: success_stories_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.success_stories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.success_stories_id_seq OWNER TO nick_nack;

--
-- Name: success_stories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.success_stories_id_seq OWNED BY public.success_stories.id;


--
-- Name: task_dataset_file_downloads; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.task_dataset_file_downloads (
    id bigint NOT NULL,
    participant_id bigint,
    task_dataset_file_id bigint,
    ip_address character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.task_dataset_file_downloads OWNER TO nick_nack;

--
-- Name: task_dataset_file_downloads_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.task_dataset_file_downloads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_dataset_file_downloads_id_seq OWNER TO nick_nack;

--
-- Name: task_dataset_file_downloads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.task_dataset_file_downloads_id_seq OWNED BY public.task_dataset_file_downloads.id;


--
-- Name: task_dataset_files; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.task_dataset_files (
    id bigint NOT NULL,
    clef_task_id bigint,
    seq integer DEFAULT 0,
    description character varying,
    evaluation boolean DEFAULT false,
    title character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    dataset_file_s3_key character varying
);


ALTER TABLE public.task_dataset_files OWNER TO nick_nack;

--
-- Name: task_dataset_files_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.task_dataset_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_dataset_files_id_seq OWNER TO nick_nack;

--
-- Name: task_dataset_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.task_dataset_files_id_seq OWNED BY public.task_dataset_files.id;


--
-- Name: team_invitations; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.team_invitations (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    invitor_id bigint NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    invitee_type character varying NOT NULL,
    invitee_id bigint NOT NULL
);


ALTER TABLE public.team_invitations OWNER TO nick_nack;

--
-- Name: team_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.team_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_invitations_id_seq OWNER TO nick_nack;

--
-- Name: team_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.team_invitations_id_seq OWNED BY public.team_invitations.id;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.team_members (
    id bigint NOT NULL,
    name character varying,
    title character varying,
    section character varying,
    description character varying,
    seq integer,
    participant_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.team_members OWNER TO nick_nack;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.team_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_members_id_seq OWNER TO nick_nack;

--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.team_members_id_seq OWNED BY public.team_members.id;


--
-- Name: team_participants; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.team_participants (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    participant_id bigint NOT NULL,
    role character varying DEFAULT 'member'::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.team_participants OWNER TO nick_nack;

--
-- Name: team_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.team_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_participants_id_seq OWNER TO nick_nack;

--
-- Name: team_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.team_participants_id_seq OWNED BY public.team_participants.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.teams (
    id bigint NOT NULL,
    challenge_id bigint NOT NULL,
    name public.citext NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.teams OWNER TO nick_nack;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO nick_nack;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: user_ratings; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.user_ratings (
    id bigint NOT NULL,
    participant_id bigint,
    rating double precision,
    temporary_rating double precision,
    variation double precision,
    temporary_variation double precision,
    challenge_round_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_ratings OWNER TO nick_nack;

--
-- Name: user_ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.user_ratings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_ratings_id_seq OWNER TO nick_nack;

--
-- Name: user_ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.user_ratings_id_seq OWNED BY public.user_ratings.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: nick_nack
--

CREATE TABLE public.versions (
    id bigint NOT NULL,
    item_type character varying NOT NULL,
    item_id bigint NOT NULL,
    event character varying NOT NULL,
    whodunnit character varying,
    object text,
    created_at timestamp without time zone,
    object_changes text
);


ALTER TABLE public.versions OWNER TO nick_nack;

--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.versions_id_seq OWNER TO nick_nack;

--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: votes_id_seq; Type: SEQUENCE; Schema: public; Owner: nick_nack
--

CREATE SEQUENCE public.votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.votes_id_seq OWNER TO nick_nack;

--
-- Name: votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nick_nack
--

ALTER SEQUENCE public.votes_id_seq OWNED BY public.votes.id;


--
-- Name: active_admin_comments id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.active_admin_comments ALTER COLUMN id SET DEFAULT nextval('public.active_admin_comments_id_seq'::regclass);


--
-- Name: active_storage_attachments id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.active_storage_attachments ALTER COLUMN id SET DEFAULT nextval('public.active_storage_attachments_id_seq'::regclass);


--
-- Name: active_storage_blobs id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.active_storage_blobs ALTER COLUMN id SET DEFAULT nextval('public.active_storage_blobs_id_seq'::regclass);


--
-- Name: ahoy_events id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ahoy_events ALTER COLUMN id SET DEFAULT nextval('public.ahoy_events_id_seq'::regclass);


--
-- Name: ahoy_visits id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ahoy_visits ALTER COLUMN id SET DEFAULT nextval('public.ahoy_visits_id_seq'::regclass);


--
-- Name: aicrowd_badges id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_badges ALTER COLUMN id SET DEFAULT nextval('public.aicrowd_badges_id_seq'::regclass);


--
-- Name: aicrowd_user_badges id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_user_badges ALTER COLUMN id SET DEFAULT nextval('public.aicrowd_user_badges_id_seq'::regclass);


--
-- Name: badge_types id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.badge_types ALTER COLUMN id SET DEFAULT nextval('public.badge_types_id_seq'::regclass);


--
-- Name: badges_events id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.badges_events ALTER COLUMN id SET DEFAULT nextval('public.badges_events_id_seq'::regclass);


--
-- Name: base_leaderboards id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.base_leaderboards ALTER COLUMN id SET DEFAULT nextval('public.base_leaderboards_id_seq'::regclass);


--
-- Name: blazer_audits id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_audits ALTER COLUMN id SET DEFAULT nextval('public.blazer_audits_id_seq'::regclass);


--
-- Name: blazer_checks id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_checks ALTER COLUMN id SET DEFAULT nextval('public.blazer_checks_id_seq'::regclass);


--
-- Name: blazer_dashboard_queries id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_dashboard_queries ALTER COLUMN id SET DEFAULT nextval('public.blazer_dashboard_queries_id_seq'::regclass);


--
-- Name: blazer_dashboards id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_dashboards ALTER COLUMN id SET DEFAULT nextval('public.blazer_dashboards_id_seq'::regclass);


--
-- Name: blazer_queries id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_queries ALTER COLUMN id SET DEFAULT nextval('public.blazer_queries_id_seq'::regclass);


--
-- Name: blogs id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blogs ALTER COLUMN id SET DEFAULT nextval('public.blogs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: category_challenges id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.category_challenges ALTER COLUMN id SET DEFAULT nextval('public.category_challenges_id_seq'::regclass);


--
-- Name: challenge_call_responses id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_call_responses ALTER COLUMN id SET DEFAULT nextval('public.challenge_call_responses_id_seq'::regclass);


--
-- Name: challenge_calls id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_calls ALTER COLUMN id SET DEFAULT nextval('public.challenge_calls_id_seq'::regclass);


--
-- Name: challenge_participants id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_participants ALTER COLUMN id SET DEFAULT nextval('public.challenge_participants_id_seq'::regclass);


--
-- Name: challenge_partners id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_partners ALTER COLUMN id SET DEFAULT nextval('public.challenge_partners_id_seq'::regclass);


--
-- Name: challenge_problems id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_problems ALTER COLUMN id SET DEFAULT nextval('public.challenge_problems_id_seq'::regclass);


--
-- Name: challenge_rounds id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_rounds ALTER COLUMN id SET DEFAULT nextval('public.challenge_rounds_id_seq'::regclass);


--
-- Name: challenge_rules id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_rules ALTER COLUMN id SET DEFAULT nextval('public.challenge_rules_id_seq'::regclass);


--
-- Name: challenges id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenges ALTER COLUMN id SET DEFAULT nextval('public.challenges_id_seq'::regclass);


--
-- Name: challenges_organizers id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenges_organizers ALTER COLUMN id SET DEFAULT nextval('public.challenges_organizers_id_seq'::regclass);


--
-- Name: ckeditor_assets id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ckeditor_assets ALTER COLUMN id SET DEFAULT nextval('public.ckeditor_assets_id_seq'::regclass);


--
-- Name: clef_tasks id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.clef_tasks ALTER COLUMN id SET DEFAULT nextval('public.clef_tasks_id_seq'::regclass);


--
-- Name: dataset_file_downloads id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_file_downloads ALTER COLUMN id SET DEFAULT nextval('public.dataset_file_downloads_id_seq'::regclass);


--
-- Name: dataset_files id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_files ALTER COLUMN id SET DEFAULT nextval('public.dataset_files_id_seq'::regclass);


--
-- Name: dataset_folders id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_folders ALTER COLUMN id SET DEFAULT nextval('public.dataset_folders_id_seq'::regclass);


--
-- Name: discourse_user_badges_meta id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.discourse_user_badges_meta ALTER COLUMN id SET DEFAULT nextval('public.discourse_user_badges_meta_id_seq'::regclass);


--
-- Name: disentanglement_leaderboards id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.disentanglement_leaderboards ALTER COLUMN id SET DEFAULT nextval('public.disentanglement_leaderboards_id_seq'::regclass);


--
-- Name: email_invitations id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_invitations ALTER COLUMN id SET DEFAULT nextval('public.email_invitations_id_seq'::regclass);


--
-- Name: email_preferences id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_preferences ALTER COLUMN id SET DEFAULT nextval('public.email_preferences_id_seq'::regclass);


--
-- Name: email_preferences_tokens id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_preferences_tokens ALTER COLUMN id SET DEFAULT nextval('public.email_preferences_tokens_id_seq'::regclass);


--
-- Name: follows id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.follows ALTER COLUMN id SET DEFAULT nextval('public.follows_id_seq'::regclass);


--
-- Name: friendly_id_slugs id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.friendly_id_slugs ALTER COLUMN id SET DEFAULT nextval('public.friendly_id_slugs_id_seq'::regclass);


--
-- Name: invitations id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.invitations ALTER COLUMN id SET DEFAULT nextval('public.invitations_id_seq'::regclass);


--
-- Name: job_postings id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.job_postings ALTER COLUMN id SET DEFAULT nextval('public.job_postings_id_seq'::regclass);


--
-- Name: mandrill_messages id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.mandrill_messages ALTER COLUMN id SET DEFAULT nextval('public.mandrill_messages_id_seq'::regclass);


--
-- Name: migration_mappings id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.migration_mappings ALTER COLUMN id SET DEFAULT nextval('public.migration_mappings_id_seq'::regclass);


--
-- Name: newsletter_emails id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.newsletter_emails ALTER COLUMN id SET DEFAULT nextval('public.newsletter_emails_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: oauth_access_grants id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_access_grants ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_grants_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_applications id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_applications ALTER COLUMN id SET DEFAULT nextval('public.oauth_applications_id_seq'::regclass);


--
-- Name: organizer_applications id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.organizer_applications ALTER COLUMN id SET DEFAULT nextval('public.organizer_applications_id_seq'::regclass);


--
-- Name: organizers id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.organizers ALTER COLUMN id SET DEFAULT nextval('public.organizers_id_seq'::regclass);


--
-- Name: participant_clef_tasks id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_clef_tasks ALTER COLUMN id SET DEFAULT nextval('public.participant_clef_tasks_id_seq'::regclass);


--
-- Name: participant_organizers id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_organizers ALTER COLUMN id SET DEFAULT nextval('public.participant_organizers_id_seq'::regclass);


--
-- Name: participants id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participants ALTER COLUMN id SET DEFAULT nextval('public.participants_id_seq'::regclass);


--
-- Name: participation_terms id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participation_terms ALTER COLUMN id SET DEFAULT nextval('public.participation_terms_id_seq'::regclass);


--
-- Name: partners id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.partners ALTER COLUMN id SET DEFAULT nextval('public.partners_id_seq'::regclass);


--
-- Name: reserved_userhandles id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.reserved_userhandles ALTER COLUMN id SET DEFAULT nextval('public.reserved_userhandles_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: submission_file_definitions id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_file_definitions ALTER COLUMN id SET DEFAULT nextval('public.submission_file_definitions_id_seq'::regclass);


--
-- Name: submission_files id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_files ALTER COLUMN id SET DEFAULT nextval('public.submission_files_id_seq'::regclass);


--
-- Name: submission_grades id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_grades ALTER COLUMN id SET DEFAULT nextval('public.submission_grades_id_seq'::regclass);


--
-- Name: submissions id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submissions ALTER COLUMN id SET DEFAULT nextval('public.submissions_id_seq'::regclass);


--
-- Name: success_stories id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.success_stories ALTER COLUMN id SET DEFAULT nextval('public.success_stories_id_seq'::regclass);


--
-- Name: task_dataset_file_downloads id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.task_dataset_file_downloads ALTER COLUMN id SET DEFAULT nextval('public.task_dataset_file_downloads_id_seq'::regclass);


--
-- Name: task_dataset_files id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.task_dataset_files ALTER COLUMN id SET DEFAULT nextval('public.task_dataset_files_id_seq'::regclass);


--
-- Name: team_invitations id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_invitations ALTER COLUMN id SET DEFAULT nextval('public.team_invitations_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_members ALTER COLUMN id SET DEFAULT nextval('public.team_members_id_seq'::regclass);


--
-- Name: team_participants id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_participants ALTER COLUMN id SET DEFAULT nextval('public.team_participants_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: user_ratings id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.user_ratings ALTER COLUMN id SET DEFAULT nextval('public.user_ratings_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Name: votes id; Type: DEFAULT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.votes ALTER COLUMN id SET DEFAULT nextval('public.votes_id_seq'::regclass);


--
-- Data for Name: active_admin_comments; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.active_admin_comments (id, namespace, body, resource_id, resource_type, author_type, author_id, created_at, updated_at) FROM stdin;
\.
COPY public.active_admin_comments (id, namespace, body, resource_id, resource_type, author_type, author_id, created_at, updated_at) FROM '$$PATH$$/4122.dat';

--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.active_storage_attachments (id, name, record_type, record_id, blob_id, created_at) FROM stdin;
\.
COPY public.active_storage_attachments (id, name, record_type, record_id, blob_id, created_at) FROM '$$PATH$$/4124.dat';

--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.active_storage_blobs (id, key, filename, content_type, metadata, byte_size, checksum, created_at) FROM stdin;
\.
COPY public.active_storage_blobs (id, key, filename, content_type, metadata, byte_size, checksum, created_at) FROM '$$PATH$$/4126.dat';

--
-- Data for Name: ahoy_events; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.ahoy_events (id, visit_id, user_id, name, properties, "time") FROM stdin;
\.
COPY public.ahoy_events (id, visit_id, user_id, name, properties, "time") FROM '$$PATH$$/4128.dat';

--
-- Data for Name: ahoy_visits; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.ahoy_visits (id, visit_token, visitor_token, user_id, ip, user_agent, referrer, referring_domain, landing_page, browser, os, device_type, country, region, city, latitude, longitude, utm_source, utm_medium, utm_term, utm_content, utm_campaign, app_version, os_version, platform, started_at) FROM stdin;
\.
COPY public.ahoy_visits (id, visit_token, visitor_token, user_id, ip, user_agent, referrer, referring_domain, landing_page, browser, os, device_type, country, region, city, latitude, longitude, utm_source, utm_medium, utm_term, utm_content, utm_campaign, app_version, os_version, platform, started_at) FROM '$$PATH$$/4130.dat';

--
-- Data for Name: aicrowd_badges; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.aicrowd_badges (id, name, description, badge_type_id, created_at, updated_at, code, badges_event_id, image) FROM stdin;
\.
COPY public.aicrowd_badges (id, name, description, badge_type_id, created_at, updated_at, code, badges_event_id, image) FROM '$$PATH$$/4132.dat';

--
-- Data for Name: aicrowd_user_badges; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.aicrowd_user_badges (id, aicrowd_badge_id, participant_id, custom_fields, created_at, updated_at, toast_shown) FROM stdin;
\.
COPY public.aicrowd_user_badges (id, aicrowd_badge_id, participant_id, custom_fields, created_at, updated_at, toast_shown) FROM '$$PATH$$/4134.dat';

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/4136.dat';

--
-- Data for Name: badge_types; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.badge_types (id, name, color_hexcode, created_at, updated_at) FROM stdin;
\.
COPY public.badge_types (id, name, color_hexcode, created_at, updated_at) FROM '$$PATH$$/4137.dat';

--
-- Data for Name: badges_events; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.badges_events (id, name, description, created_at, updated_at) FROM stdin;
\.
COPY public.badges_events (id, name, description, created_at, updated_at) FROM '$$PATH$$/4139.dat';

--
-- Data for Name: base_leaderboards; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.base_leaderboards (id, challenge_id, challenge_round_id, row_num, previous_row_num, slug, name, entries, score, score_secondary, media_large, media_thumbnail, media_content_type, description, description_markdown, leaderboard_type_cd, refreshed_at, created_at, updated_at, submission_id, post_challenge, seq, baseline, baseline_comment, meta, submitter_type, submitter_id, meta_challenge_id) FROM stdin;
\.
COPY public.base_leaderboards (id, challenge_id, challenge_round_id, row_num, previous_row_num, slug, name, entries, score, score_secondary, media_large, media_thumbnail, media_content_type, description, description_markdown, leaderboard_type_cd, refreshed_at, created_at, updated_at, submission_id, post_challenge, seq, baseline, baseline_comment, meta, submitter_type, submitter_id, meta_challenge_id) FROM '$$PATH$$/4141.dat';

--
-- Data for Name: base_leaderboards_20180809; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.base_leaderboards_20180809 (id, challenge_id, challenge_round_id, participant_id, row_num, previous_row_num, slug, name, entries, score, score_secondary, media_large, media_thumbnail, media_content_type, description, description_markdown, leaderboard_type_cd, refreshed_at, created_at, updated_at, submission_id, post_challenge) FROM stdin;
\.
COPY public.base_leaderboards_20180809 (id, challenge_id, challenge_round_id, participant_id, row_num, previous_row_num, slug, name, entries, score, score_secondary, media_large, media_thumbnail, media_content_type, description, description_markdown, leaderboard_type_cd, refreshed_at, created_at, updated_at, submission_id, post_challenge) FROM '$$PATH$$/4142.dat';

--
-- Data for Name: blazer_audits; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.blazer_audits (id, user_id, query_id, statement, data_source, created_at) FROM stdin;
\.
COPY public.blazer_audits (id, user_id, query_id, statement, data_source, created_at) FROM '$$PATH$$/4144.dat';

--
-- Data for Name: blazer_checks; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.blazer_checks (id, creator_id, query_id, state, schedule, emails, slack_channels, check_type, message, last_run_at, created_at, updated_at) FROM stdin;
\.
COPY public.blazer_checks (id, creator_id, query_id, state, schedule, emails, slack_channels, check_type, message, last_run_at, created_at, updated_at) FROM '$$PATH$$/4146.dat';

--
-- Data for Name: blazer_dashboard_queries; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.blazer_dashboard_queries (id, dashboard_id, query_id, "position", created_at, updated_at) FROM stdin;
\.
COPY public.blazer_dashboard_queries (id, dashboard_id, query_id, "position", created_at, updated_at) FROM '$$PATH$$/4148.dat';

--
-- Data for Name: blazer_dashboards; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.blazer_dashboards (id, creator_id, name, created_at, updated_at) FROM stdin;
\.
COPY public.blazer_dashboards (id, creator_id, name, created_at, updated_at) FROM '$$PATH$$/4150.dat';

--
-- Data for Name: blazer_queries; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.blazer_queries (id, creator_id, name, description, statement, data_source, created_at, updated_at) FROM stdin;
\.
COPY public.blazer_queries (id, creator_id, name, description, statement, data_source, created_at, updated_at) FROM '$$PATH$$/4152.dat';

--
-- Data for Name: blogs; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.blogs (id, participant_id, title, body, published, vote_count, view_count, created_at, updated_at, seq, posted_at, slug) FROM stdin;
\.
COPY public.blogs (id, participant_id, title, body, published, vote_count, view_count, created_at, updated_at, seq, posted_at, slug) FROM '$$PATH$$/4154.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.categories (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.categories (id, name, created_at, updated_at) FROM '$$PATH$$/4156.dat';

--
-- Data for Name: category_challenges; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.category_challenges (id, category_id, challenge_id, created_at, updated_at) FROM stdin;
\.
COPY public.category_challenges (id, category_id, challenge_id, created_at, updated_at) FROM '$$PATH$$/4158.dat';

--
-- Data for Name: challenge_call_responses; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_call_responses (id, challenge_call_id, email, phone, organization, created_at, updated_at, challenge_description, contact_name, challenge_title, motivation, timeline, evaluation_criteria, organizers_bio, other) FROM stdin;
\.
COPY public.challenge_call_responses (id, challenge_call_id, email, phone, organization, created_at, updated_at, challenge_description, contact_name, challenge_title, motivation, timeline, evaluation_criteria, organizers_bio, other) FROM '$$PATH$$/4160.dat';

--
-- Data for Name: challenge_calls; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_calls (id, title, website, closing_date, description, created_at, updated_at, slug, organizer_id, headline, acknowledged) FROM stdin;
\.
COPY public.challenge_calls (id, title, website, closing_date, description, created_at, updated_at, slug, organizer_id, headline, acknowledged) FROM '$$PATH$$/4162.dat';

--
-- Data for Name: challenge_participants; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_participants (id, challenge_id, participant_id, email, name, registered, clef_task_id, clef_eua_file, clef_approved, clef_status_cd, created_at, updated_at, challenge_rules_accepted_date, challenge_rules_accepted_version, challenge_rules_additional_checkbox) FROM stdin;
\.
COPY public.challenge_participants (id, challenge_id, participant_id, email, name, registered, clef_task_id, clef_eua_file, clef_approved, clef_status_cd, created_at, updated_at, challenge_rules_accepted_date, challenge_rules_accepted_version, challenge_rules_additional_checkbox) FROM '$$PATH$$/4164.dat';

--
-- Data for Name: challenge_partners; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_partners (id, challenge_id, image_file, partner_url, created_at, updated_at) FROM stdin;
\.
COPY public.challenge_partners (id, challenge_id, image_file, partner_url, created_at, updated_at) FROM '$$PATH$$/4166.dat';

--
-- Data for Name: challenge_problems; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_problems (id, challenge_id, problem_id, weight, challenge_round_id) FROM stdin;
\.
COPY public.challenge_problems (id, challenge_id, problem_id, weight, challenge_round_id) FROM '$$PATH$$/4168.dat';

--
-- Data for Name: challenge_rounds; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_rounds (id, challenge_id, challenge_round, active, created_at, updated_at, submission_limit, submission_limit_period_cd, start_dttm, end_dttm, minimum_score, minimum_score_secondary, ranking_window, ranking_highlight, score_precision, score_secondary_precision, leaderboard_note_markdown, leaderboard_note, failed_submissions, parallel_submissions, score_title, score_secondary_title, primary_sort_order_cd, secondary_sort_order_cd, calculated_permanent, assigned_permanent_badge) FROM stdin;
\.
COPY public.challenge_rounds (id, challenge_id, challenge_round, active, created_at, updated_at, submission_limit, submission_limit_period_cd, start_dttm, end_dttm, minimum_score, minimum_score_secondary, ranking_window, ranking_highlight, score_precision, score_secondary_precision, leaderboard_note_markdown, leaderboard_note, failed_submissions, parallel_submissions, score_title, score_secondary_title, primary_sort_order_cd, secondary_sort_order_cd, calculated_permanent, assigned_permanent_badge) FROM '$$PATH$$/4176.dat';

--
-- Data for Name: challenge_rules; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenge_rules (id, challenge_id, terms, terms_markdown, instructions, instructions_markdown, has_additional_checkbox, additional_checkbox_text, version, created_at, updated_at, additional_checkbox_text_markdown) FROM stdin;
\.
COPY public.challenge_rules (id, challenge_id, terms, terms_markdown, instructions, instructions_markdown, has_additional_checkbox, additional_checkbox_text, version, created_at, updated_at, additional_checkbox_text_markdown) FROM '$$PATH$$/4178.dat';

--
-- Data for Name: challenges; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenges (id, challenge, status_cd, created_at, updated_at, tagline, perpetual_challenge, answer_file_s3_key, page_views, participant_count, submissions_count, slug, submission_license, api_required, media_on_leaderboard, challenge_client_name, online_grading, vote_count, description_markdown, description, evaluation_markdown, evaluation, rules_markdown, rules, prizes_markdown, prizes, resources_markdown, resources, submission_instructions_markdown, submission_instructions, license_markdown, license, dataset_description_markdown, dataset_description, image_file, featured_sequence, dynamic_content_flag, dynamic_content, dynamic_content_tab, winner_description_markdown, winner_description, winners_tab_active, clef_task_id, clef_challenge, submissions_page, private_challenge, show_leaderboard, grader_identifier, online_submissions, grader_logs, require_registration, grading_history, post_challenge_submissions, submissions_downloadable, dataset_note_markdown, dataset_note, discussions_visible, require_toc_acceptance, toc_acceptance_text, toc_acceptance_instructions, toc_acceptance_instructions_markdown, toc_accordion, dynamic_content_url, prize_cash, prize_travel, prize_academic, prize_misc, discourse_category_id, latest_submission, other_scores_fieldnames, teams_allowed, max_team_participants, team_freeze_seconds_before_end, hidden_challenge, team_freeze_time, evaluator_type_cd, scrollable_overview_tabs, discourse_group_id, discourse_group_name, meta_challenge, practice_flag, banner_file, banner_color, big_challenge_card_image, banner_mobile_file, weight, editors_selection) FROM stdin;
\.
COPY public.challenges (id, challenge, status_cd, created_at, updated_at, tagline, perpetual_challenge, answer_file_s3_key, page_views, participant_count, submissions_count, slug, submission_license, api_required, media_on_leaderboard, challenge_client_name, online_grading, vote_count, description_markdown, description, evaluation_markdown, evaluation, rules_markdown, rules, prizes_markdown, prizes, resources_markdown, resources, submission_instructions_markdown, submission_instructions, license_markdown, license, dataset_description_markdown, dataset_description, image_file, featured_sequence, dynamic_content_flag, dynamic_content, dynamic_content_tab, winner_description_markdown, winner_description, winners_tab_active, clef_task_id, clef_challenge, submissions_page, private_challenge, show_leaderboard, grader_identifier, online_submissions, grader_logs, require_registration, grading_history, post_challenge_submissions, submissions_downloadable, dataset_note_markdown, dataset_note, discussions_visible, require_toc_acceptance, toc_acceptance_text, toc_acceptance_instructions, toc_acceptance_instructions_markdown, toc_accordion, dynamic_content_url, prize_cash, prize_travel, prize_academic, prize_misc, discourse_category_id, latest_submission, other_scores_fieldnames, teams_allowed, max_team_participants, team_freeze_seconds_before_end, hidden_challenge, team_freeze_time, evaluator_type_cd, scrollable_overview_tabs, discourse_group_id, discourse_group_name, meta_challenge, practice_flag, banner_file, banner_color, big_challenge_card_image, banner_mobile_file, weight, editors_selection) FROM '$$PATH$$/4170.dat';

--
-- Data for Name: challenges_organizers; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.challenges_organizers (id, challenge_id, organizer_id, created_at, updated_at) FROM stdin;
\.
COPY public.challenges_organizers (id, challenge_id, organizer_id, created_at, updated_at) FROM '$$PATH$$/4182.dat';

--
-- Data for Name: ckeditor_assets; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.ckeditor_assets (id, data_file_name, data_content_type, data_file_size, type, created_at, updated_at) FROM stdin;
\.
COPY public.ckeditor_assets (id, data_file_name, data_content_type, data_file_size, type, created_at, updated_at) FROM '$$PATH$$/4184.dat';

--
-- Data for Name: clef_tasks; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.clef_tasks (id, organizer_id, task, created_at, updated_at, eua_file, use_challenge_dataset_files) FROM stdin;
\.
COPY public.clef_tasks (id, organizer_id, task, created_at, updated_at, eua_file, use_challenge_dataset_files) FROM '$$PATH$$/4186.dat';

--
-- Data for Name: dataset_file_downloads; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.dataset_file_downloads (id, participant_id, dataset_file_id, ip_address, created_at, updated_at) FROM stdin;
\.
COPY public.dataset_file_downloads (id, participant_id, dataset_file_id, ip_address, created_at, updated_at) FROM '$$PATH$$/4171.dat';

--
-- Data for Name: dataset_files; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.dataset_files (id, seq, created_at, updated_at, description, challenge_id, dataset_file_s3_key, evaluation, title, hosting_location, external_url, visible, external_file_size, file_path, aws_access_key, aws_secret_key, bucket_name, region) FROM stdin;
\.
COPY public.dataset_files (id, seq, created_at, updated_at, description, challenge_id, dataset_file_s3_key, evaluation, title, hosting_location, external_url, visible, external_file_size, file_path, aws_access_key, aws_secret_key, bucket_name, region) FROM '$$PATH$$/4172.dat';

--
-- Data for Name: dataset_folders; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.dataset_folders (id, title, description, directory_path, aws_access_key, aws_secret_key, bucket_name, region, visible, evaluation, challenge_id, created_at, updated_at, aws_endpoint) FROM stdin;
\.
COPY public.dataset_folders (id, title, description, directory_path, aws_access_key, aws_secret_key, bucket_name, region, visible, evaluation, challenge_id, created_at, updated_at, aws_endpoint) FROM '$$PATH$$/4190.dat';

--
-- Data for Name: discourse_user_badges_meta; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.discourse_user_badges_meta (id, previous_id, created_at, updated_at) FROM stdin;
\.
COPY public.discourse_user_badges_meta (id, previous_id, created_at, updated_at) FROM '$$PATH$$/4192.dat';

--
-- Data for Name: disentanglement_leaderboards; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.disentanglement_leaderboards (id, challenge_id, challenge_round_id, participant_id, row_num, previous_row_num, slug, name, entries, score, score_secondary, media_large, media_thumbnail, media_content_type, description, description_markdown, leaderboard_type_cd, refreshed_at, created_at, updated_at, submission_id, post_challenge, seq, baseline, baseline_comment, meta, extra_score1, extra_score2, extra_score3, extra_score4, extra_score5, avg_rank) FROM stdin;
\.
COPY public.disentanglement_leaderboards (id, challenge_id, challenge_round_id, participant_id, row_num, previous_row_num, slug, name, entries, score, score_secondary, media_large, media_thumbnail, media_content_type, description, description_markdown, leaderboard_type_cd, refreshed_at, created_at, updated_at, submission_id, post_challenge, seq, baseline, baseline_comment, meta, extra_score1, extra_score2, extra_score3, extra_score4, extra_score5, avg_rank) FROM '$$PATH$$/4194.dat';

--
-- Data for Name: email_invitations; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.email_invitations (id, invitor_id, email, token, claimant_id, claimed_at, created_at, updated_at) FROM stdin;
\.
COPY public.email_invitations (id, invitor_id, email, token, claimant_id, claimed_at, created_at, updated_at) FROM '$$PATH$$/4196.dat';

--
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.email_preferences (id, participant_id, newsletter, created_at, updated_at, challenges_followed, mentions, email_frequency_cd) FROM stdin;
\.
COPY public.email_preferences (id, participant_id, newsletter, created_at, updated_at, challenges_followed, mentions, email_frequency_cd) FROM '$$PATH$$/4198.dat';

--
-- Data for Name: email_preferences_tokens; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.email_preferences_tokens (id, participant_id, email_preferences_token, token_expiration_dttm, created_at, updated_at) FROM stdin;
\.
COPY public.email_preferences_tokens (id, participant_id, email_preferences_token, token_expiration_dttm, created_at, updated_at) FROM '$$PATH$$/4200.dat';

--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.follows (id, followable_id, followable_type, participant_id, created_at, updated_at) FROM stdin;
\.
COPY public.follows (id, followable_id, followable_type, participant_id, created_at, updated_at) FROM '$$PATH$$/4202.dat';

--
-- Data for Name: friendly_id_slugs; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.friendly_id_slugs (id, slug, sluggable_id, sluggable_type, scope, created_at) FROM stdin;
\.
COPY public.friendly_id_slugs (id, slug, sluggable_id, sluggable_type, scope, created_at) FROM '$$PATH$$/4204.dat';

--
-- Data for Name: invitations; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.invitations (id, challenge_id, participant_id, email, created_at, updated_at, invitee_name) FROM stdin;
\.
COPY public.invitations (id, challenge_id, participant_id, email, created_at, updated_at, invitee_name) FROM '$$PATH$$/4206.dat';

--
-- Data for Name: job_postings; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.job_postings (id, title, organisation, contact_name, contact_email, contact_phone, posting_date, closing_date, status_cd, description, remote, location, country, page_views, created_at, updated_at, job_url, slug) FROM stdin;
\.
COPY public.job_postings (id, title, organisation, contact_name, contact_email, contact_phone, posting_date, closing_date, status_cd, description, remote, location, country, page_views, created_at, updated_at, job_url, slug) FROM '$$PATH$$/4208.dat';

--
-- Data for Name: mandrill_messages; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.mandrill_messages (id, res, message, meta, created_at, updated_at, participant_id) FROM stdin;
\.
COPY public.mandrill_messages (id, res, message, meta, created_at, updated_at, participant_id) FROM '$$PATH$$/4210.dat';

--
-- Data for Name: migration_mappings; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.migration_mappings (id, source_type, source_id, crowdai_participant_id, created_at, updated_at) FROM stdin;
\.
COPY public.migration_mappings (id, source_type, source_id, crowdai_participant_id, created_at, updated_at) FROM '$$PATH$$/4212.dat';

--
-- Data for Name: newsletter_emails; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.newsletter_emails (id, bcc, cc, subject, message, pending, created_at, updated_at, participant_id, challenge_id, decline_reason) FROM stdin;
\.
COPY public.newsletter_emails (id, bcc, cc, subject, message, pending, created_at, updated_at, participant_id, challenge_id, decline_reason) FROM '$$PATH$$/4214.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.notifications (id, participant_id, notification_type, notifiable_type, notifiable_id, read_at, is_new, created_at, updated_at, message, thumbnail_url, notification_url) FROM stdin;
\.
COPY public.notifications (id, participant_id, notification_type, notifiable_type, notifiable_id, read_at, is_new, created_at, updated_at, message, thumbnail_url, notification_url) FROM '$$PATH$$/4216.dat';

--
-- Data for Name: oauth_access_grants; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.oauth_access_grants (id, resource_owner_id, application_id, token, expires_in, redirect_uri, created_at, revoked_at, scopes) FROM stdin;
\.
COPY public.oauth_access_grants (id, resource_owner_id, application_id, token, expires_in, redirect_uri, created_at, revoked_at, scopes) FROM '$$PATH$$/4218.dat';

--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.oauth_access_tokens (id, resource_owner_id, application_id, token, refresh_token, expires_in, revoked_at, created_at, scopes, previous_refresh_token) FROM stdin;
\.
COPY public.oauth_access_tokens (id, resource_owner_id, application_id, token, refresh_token, expires_in, revoked_at, created_at, scopes, previous_refresh_token) FROM '$$PATH$$/4220.dat';

--
-- Data for Name: oauth_applications; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.oauth_applications (id, name, uid, secret, redirect_uri, scopes, confidential, created_at, updated_at) FROM stdin;
\.
COPY public.oauth_applications (id, name, uid, secret, redirect_uri, scopes, confidential, created_at, updated_at) FROM '$$PATH$$/4222.dat';

--
-- Data for Name: organizer_applications; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.organizer_applications (id, contact_name, email, phone, organization, organization_description, challenge_description, created_at, updated_at) FROM stdin;
\.
COPY public.organizer_applications (id, contact_name, email, phone, organization, organization_description, challenge_description, created_at, updated_at) FROM '$$PATH$$/4224.dat';

--
-- Data for Name: organizers; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.organizers (id, organizer, address, description, created_at, updated_at, approved, slug, image_file, tagline, challenge_proposal, api_key, clef_organizer) FROM stdin;
\.
COPY public.organizers (id, organizer, address, description, created_at, updated_at, approved, slug, image_file, tagline, challenge_proposal, api_key, clef_organizer) FROM '$$PATH$$/4226.dat';

--
-- Data for Name: participant_clef_tasks; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.participant_clef_tasks (id, participant_id, clef_task_id, approved, eua_file, created_at, updated_at, status_cd) FROM stdin;
\.
COPY public.participant_clef_tasks (id, participant_id, clef_task_id, approved, eua_file, created_at, updated_at, status_cd) FROM '$$PATH$$/4173.dat';

--
-- Data for Name: participant_organizers; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.participant_organizers (id, participant_id, organizer_id, created_at, updated_at) FROM stdin;
\.
COPY public.participant_organizers (id, participant_id, organizer_id, created_at, updated_at) FROM '$$PATH$$/4229.dat';

--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.participants (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, confirmation_token, confirmed_at, confirmation_sent_at, failed_attempts, unlock_token, locked_at, admin, verified, verification_date, timezone, created_at, updated_at, unconfirmed_email, name, email_public, bio, website, github, linkedin, twitter, account_disabled, account_disabled_reason, account_disabled_dttm, slug, api_key, image_file, affiliation, country_cd, address, city, first_name, last_name, clef_email, provider, uid, participation_terms_accepted_date, participation_terms_accepted_version, agreed_to_terms_of_use_and_privacy, agreed_to_marketing, rating, temporary_rating, variation, temporary_variation, ranking, ranking_change, agreed_to_organizers_newsletter, fixed_rating) FROM stdin;
\.
COPY public.participants (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, confirmation_token, confirmed_at, confirmation_sent_at, failed_attempts, unlock_token, locked_at, admin, verified, verification_date, timezone, created_at, updated_at, unconfirmed_email, name, email_public, bio, website, github, linkedin, twitter, account_disabled, account_disabled_reason, account_disabled_dttm, slug, api_key, image_file, affiliation, country_cd, address, city, first_name, last_name, clef_email, provider, uid, participation_terms_accepted_date, participation_terms_accepted_version, agreed_to_terms_of_use_and_privacy, agreed_to_marketing, rating, temporary_rating, variation, temporary_variation, ranking, ranking_change, agreed_to_organizers_newsletter, fixed_rating) FROM '$$PATH$$/4180.dat';

--
-- Data for Name: participation_terms; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.participation_terms (id, terms, instructions, instructions_markdown, version, created_at, updated_at) FROM stdin;
\.
COPY public.participation_terms (id, terms, instructions, instructions_markdown, version, created_at, updated_at) FROM '$$PATH$$/4233.dat';

--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.partners (id, organizer_id, image_file, visible, seq, created_at, updated_at, name) FROM stdin;
\.
COPY public.partners (id, organizer_id, image_file, visible, seq, created_at, updated_at, name) FROM '$$PATH$$/4235.dat';

--
-- Data for Name: reserved_userhandles; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.reserved_userhandles (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.reserved_userhandles (id, name, created_at, updated_at) FROM '$$PATH$$/4237.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/4239.dat';

--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.settings (id, jobs_visible, created_at, updated_at, banner_text, banner_color, enable_banner, footer_text, enable_footer) FROM stdin;
\.
COPY public.settings (id, jobs_visible, created_at, updated_at, banner_text, banner_color, enable_banner, footer_text, enable_footer) FROM '$$PATH$$/4240.dat';

--
-- Data for Name: submission_file_definitions; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.submission_file_definitions (id, challenge_id, seq, submission_file_description, filetype_cd, file_required, submission_file_help_text, created_at, updated_at) FROM stdin;
\.
COPY public.submission_file_definitions (id, challenge_id, seq, submission_file_description, filetype_cd, file_required, submission_file_help_text, created_at, updated_at) FROM '$$PATH$$/4242.dat';

--
-- Data for Name: submission_files; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.submission_files (id, submission_id, seq, created_at, updated_at, submission_file_s3_key, leaderboard_video, submission_type) FROM stdin;
\.
COPY public.submission_files (id, submission_id, seq, created_at, updated_at, submission_file_s3_key, leaderboard_video, submission_type) FROM '$$PATH$$/4231.dat';

--
-- Data for Name: submission_grades; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.submission_grades (id, submission_id, grading_status_cd, grading_message, grading_factor, score, score_secondary, created_at, updated_at, slug) FROM stdin;
\.
COPY public.submission_grades (id, submission_id, grading_status_cd, grading_message, grading_factor, score, score_secondary, created_at, updated_at, slug) FROM '$$PATH$$/4245.dat';

--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.submissions (id, challenge_id, participant_id, score, created_at, updated_at, description, score_secondary, grading_message, grading_status_cd, description_markdown, vote_count, post_challenge, api, media_large, media_thumbnail, media_content_type, challenge_round_id, meta, short_url, clef_method_description, clef_retrieval_type, clef_run_type, clef_primary_run, clef_other_info, clef_additional, online_submission, score_display, score_secondary_display, baseline, baseline_comment, meta_challenge_id, submission_link) FROM stdin;
\.
COPY public.submissions (id, challenge_id, participant_id, score, created_at, updated_at, description, score_secondary, grading_message, grading_status_cd, description_markdown, vote_count, post_challenge, api, media_large, media_thumbnail, media_content_type, challenge_round_id, meta, short_url, clef_method_description, clef_retrieval_type, clef_run_type, clef_primary_run, clef_other_info, clef_additional, online_submission, score_display, score_secondary_display, baseline, baseline_comment, meta_challenge_id, submission_link) FROM '$$PATH$$/4174.dat';

--
-- Data for Name: success_stories; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.success_stories (id, title, byline, html_content, published, posted_at, seq, created_at, updated_at, slug, image_file) FROM stdin;
\.
COPY public.success_stories (id, title, byline, html_content, published, posted_at, seq, created_at, updated_at, slug, image_file) FROM '$$PATH$$/4248.dat';

--
-- Data for Name: task_dataset_file_downloads; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.task_dataset_file_downloads (id, participant_id, task_dataset_file_id, ip_address, created_at, updated_at) FROM stdin;
\.
COPY public.task_dataset_file_downloads (id, participant_id, task_dataset_file_id, ip_address, created_at, updated_at) FROM '$$PATH$$/4250.dat';

--
-- Data for Name: task_dataset_files; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.task_dataset_files (id, clef_task_id, seq, description, evaluation, title, created_at, updated_at, dataset_file_s3_key) FROM stdin;
\.
COPY public.task_dataset_files (id, clef_task_id, seq, description, evaluation, title, created_at, updated_at, dataset_file_s3_key) FROM '$$PATH$$/4252.dat';

--
-- Data for Name: team_invitations; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.team_invitations (id, team_id, invitor_id, status, uuid, created_at, updated_at, invitee_type, invitee_id) FROM stdin;
\.
COPY public.team_invitations (id, team_id, invitor_id, status, uuid, created_at, updated_at, invitee_type, invitee_id) FROM '$$PATH$$/4254.dat';

--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.team_members (id, name, title, section, description, seq, participant_id, created_at, updated_at) FROM stdin;
\.
COPY public.team_members (id, name, title, section, description, seq, participant_id, created_at, updated_at) FROM '$$PATH$$/4256.dat';

--
-- Data for Name: team_participants; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.team_participants (id, team_id, participant_id, role, created_at, updated_at) FROM stdin;
\.
COPY public.team_participants (id, team_id, participant_id, role, created_at, updated_at) FROM '$$PATH$$/4258.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.teams (id, challenge_id, name, created_at, updated_at) FROM stdin;
\.
COPY public.teams (id, challenge_id, name, created_at, updated_at) FROM '$$PATH$$/4260.dat';

--
-- Data for Name: user_ratings; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.user_ratings (id, participant_id, rating, temporary_rating, variation, temporary_variation, challenge_round_id, created_at, updated_at) FROM stdin;
\.
COPY public.user_ratings (id, participant_id, rating, temporary_rating, variation, temporary_variation, challenge_round_id, created_at, updated_at) FROM '$$PATH$$/4262.dat';

--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.versions (id, item_type, item_id, event, whodunnit, object, created_at, object_changes) FROM stdin;
\.
COPY public.versions (id, item_type, item_id, event, whodunnit, object, created_at, object_changes) FROM '$$PATH$$/4264.dat';

--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: nick_nack
--

COPY public.votes (id, votable_id, votable_type, participant_id, created_at, updated_at) FROM stdin;
\.
COPY public.votes (id, votable_id, votable_type, participant_id, created_at, updated_at) FROM '$$PATH$$/4175.dat';

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.active_admin_comments_id_seq', 1, false);


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.active_storage_attachments_id_seq', 1, false);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.active_storage_blobs_id_seq', 1, false);


--
-- Name: ahoy_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.ahoy_events_id_seq', 60, true);


--
-- Name: ahoy_visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.ahoy_visits_id_seq', 58, true);


--
-- Name: aicrowd_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.aicrowd_badges_id_seq', 1, false);


--
-- Name: aicrowd_user_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.aicrowd_user_badges_id_seq', 1, false);


--
-- Name: badge_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.badge_types_id_seq', 1, false);


--
-- Name: badges_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.badges_events_id_seq', 1, false);


--
-- Name: base_leaderboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.base_leaderboards_id_seq', 1, false);


--
-- Name: blazer_audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.blazer_audits_id_seq', 1, false);


--
-- Name: blazer_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.blazer_checks_id_seq', 1, false);


--
-- Name: blazer_dashboard_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.blazer_dashboard_queries_id_seq', 1, false);


--
-- Name: blazer_dashboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.blazer_dashboards_id_seq', 1, false);


--
-- Name: blazer_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.blazer_queries_id_seq', 1, false);


--
-- Name: blogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.blogs_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: category_challenges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.category_challenges_id_seq', 1, false);


--
-- Name: challenge_call_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_call_responses_id_seq', 1, false);


--
-- Name: challenge_calls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_calls_id_seq', 1, false);


--
-- Name: challenge_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_participants_id_seq', 1, false);


--
-- Name: challenge_partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_partners_id_seq', 1, false);


--
-- Name: challenge_problems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_problems_id_seq', 1, false);


--
-- Name: challenge_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_rounds_id_seq', 5, true);


--
-- Name: challenge_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenge_rules_id_seq', 5, true);


--
-- Name: challenges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenges_id_seq', 1, false);


--
-- Name: challenges_organizers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.challenges_organizers_id_seq', 1, false);


--
-- Name: ckeditor_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.ckeditor_assets_id_seq', 1, false);


--
-- Name: clef_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.clef_tasks_id_seq', 1, false);


--
-- Name: dataset_file_downloads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.dataset_file_downloads_id_seq', 1, false);


--
-- Name: dataset_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.dataset_files_id_seq', 1, false);


--
-- Name: dataset_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.dataset_folders_id_seq', 1, false);


--
-- Name: discourse_user_badges_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.discourse_user_badges_meta_id_seq', 1, false);


--
-- Name: disentanglement_leaderboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.disentanglement_leaderboards_id_seq', 1, false);


--
-- Name: email_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.email_invitations_id_seq', 1, false);


--
-- Name: email_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.email_preferences_id_seq', 42, true);


--
-- Name: email_preferences_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.email_preferences_tokens_id_seq', 1, false);


--
-- Name: follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.follows_id_seq', 1, false);


--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.friendly_id_slugs_id_seq', 49, true);


--
-- Name: invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.invitations_id_seq', 1, false);


--
-- Name: job_postings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.job_postings_id_seq', 1, false);


--
-- Name: mandrill_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.mandrill_messages_id_seq', 1, false);


--
-- Name: migration_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.migration_mappings_id_seq', 1, false);


--
-- Name: newsletter_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.newsletter_emails_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.oauth_access_grants_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.oauth_applications_id_seq', 1, false);


--
-- Name: organizer_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.organizer_applications_id_seq', 1, false);


--
-- Name: organizers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.organizers_id_seq', 1, false);


--
-- Name: participant_clef_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.participant_clef_tasks_id_seq', 1, false);


--
-- Name: participant_organizers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.participant_organizers_id_seq', 1, false);


--
-- Name: participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.participants_id_seq', 2, true);


--
-- Name: participation_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.participation_terms_id_seq', 1, false);


--
-- Name: partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.partners_id_seq', 1, false);


--
-- Name: reserved_userhandles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.reserved_userhandles_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: submission_file_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.submission_file_definitions_id_seq', 1, false);


--
-- Name: submission_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.submission_files_id_seq', 1, false);


--
-- Name: submission_grades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.submission_grades_id_seq', 1, false);


--
-- Name: submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.submissions_id_seq', 1, false);


--
-- Name: success_stories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.success_stories_id_seq', 1, false);


--
-- Name: task_dataset_file_downloads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.task_dataset_file_downloads_id_seq', 1, false);


--
-- Name: task_dataset_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.task_dataset_files_id_seq', 1, false);


--
-- Name: team_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.team_invitations_id_seq', 1, false);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.team_members_id_seq', 1, false);


--
-- Name: team_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.team_participants_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: user_ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.user_ratings_id_seq', 1, false);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.versions_id_seq', 1, false);


--
-- Name: votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nick_nack
--

SELECT pg_catalog.setval('public.votes_id_seq', 1, false);


--
-- Name: active_admin_comments active_admin_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.active_admin_comments
    ADD CONSTRAINT active_admin_comments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: ahoy_events ahoy_events_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ahoy_events
    ADD CONSTRAINT ahoy_events_pkey PRIMARY KEY (id);


--
-- Name: ahoy_visits ahoy_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ahoy_visits
    ADD CONSTRAINT ahoy_visits_pkey PRIMARY KEY (id);


--
-- Name: aicrowd_badges aicrowd_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_badges
    ADD CONSTRAINT aicrowd_badges_pkey PRIMARY KEY (id);


--
-- Name: aicrowd_user_badges aicrowd_user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_user_badges
    ADD CONSTRAINT aicrowd_user_badges_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: badge_types badge_types_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.badge_types
    ADD CONSTRAINT badge_types_pkey PRIMARY KEY (id);


--
-- Name: badges_events badges_events_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.badges_events
    ADD CONSTRAINT badges_events_pkey PRIMARY KEY (id);


--
-- Name: base_leaderboards base_leaderboards_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.base_leaderboards
    ADD CONSTRAINT base_leaderboards_pkey PRIMARY KEY (id);


--
-- Name: blazer_audits blazer_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_audits
    ADD CONSTRAINT blazer_audits_pkey PRIMARY KEY (id);


--
-- Name: blazer_checks blazer_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_checks
    ADD CONSTRAINT blazer_checks_pkey PRIMARY KEY (id);


--
-- Name: blazer_dashboard_queries blazer_dashboard_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_dashboard_queries
    ADD CONSTRAINT blazer_dashboard_queries_pkey PRIMARY KEY (id);


--
-- Name: blazer_dashboards blazer_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_dashboards
    ADD CONSTRAINT blazer_dashboards_pkey PRIMARY KEY (id);


--
-- Name: blazer_queries blazer_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blazer_queries
    ADD CONSTRAINT blazer_queries_pkey PRIMARY KEY (id);


--
-- Name: blogs blogs_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blogs
    ADD CONSTRAINT blogs_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_challenges category_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.category_challenges
    ADD CONSTRAINT category_challenges_pkey PRIMARY KEY (id);


--
-- Name: challenge_call_responses challenge_call_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_call_responses
    ADD CONSTRAINT challenge_call_responses_pkey PRIMARY KEY (id);


--
-- Name: challenge_calls challenge_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_calls
    ADD CONSTRAINT challenge_calls_pkey PRIMARY KEY (id);


--
-- Name: challenge_participants challenge_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_participants
    ADD CONSTRAINT challenge_participants_pkey PRIMARY KEY (id);


--
-- Name: challenge_partners challenge_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_partners
    ADD CONSTRAINT challenge_partners_pkey PRIMARY KEY (id);


--
-- Name: challenge_problems challenge_problems_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_problems
    ADD CONSTRAINT challenge_problems_pkey PRIMARY KEY (id);


--
-- Name: challenge_rounds challenge_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_rounds
    ADD CONSTRAINT challenge_rounds_pkey PRIMARY KEY (id);


--
-- Name: challenge_rules challenge_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_rules
    ADD CONSTRAINT challenge_rules_pkey PRIMARY KEY (id);


--
-- Name: challenges_organizers challenges_organizers_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenges_organizers
    ADD CONSTRAINT challenges_organizers_pkey PRIMARY KEY (id);


--
-- Name: challenges challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenges
    ADD CONSTRAINT challenges_pkey PRIMARY KEY (id);


--
-- Name: ckeditor_assets ckeditor_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.ckeditor_assets
    ADD CONSTRAINT ckeditor_assets_pkey PRIMARY KEY (id);


--
-- Name: clef_tasks clef_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.clef_tasks
    ADD CONSTRAINT clef_tasks_pkey PRIMARY KEY (id);


--
-- Name: dataset_file_downloads dataset_file_downloads_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_file_downloads
    ADD CONSTRAINT dataset_file_downloads_pkey PRIMARY KEY (id);


--
-- Name: dataset_files dataset_files_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_files
    ADD CONSTRAINT dataset_files_pkey PRIMARY KEY (id);


--
-- Name: dataset_folders dataset_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_folders
    ADD CONSTRAINT dataset_folders_pkey PRIMARY KEY (id);


--
-- Name: discourse_user_badges_meta discourse_user_badges_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.discourse_user_badges_meta
    ADD CONSTRAINT discourse_user_badges_meta_pkey PRIMARY KEY (id);


--
-- Name: disentanglement_leaderboards disentanglement_leaderboards_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.disentanglement_leaderboards
    ADD CONSTRAINT disentanglement_leaderboards_pkey PRIMARY KEY (id);


--
-- Name: email_invitations email_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_invitations
    ADD CONSTRAINT email_invitations_pkey PRIMARY KEY (id);


--
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (id);


--
-- Name: email_preferences_tokens email_preferences_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_preferences_tokens
    ADD CONSTRAINT email_preferences_tokens_pkey PRIMARY KEY (id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: friendly_id_slugs friendly_id_slugs_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.friendly_id_slugs
    ADD CONSTRAINT friendly_id_slugs_pkey PRIMARY KEY (id);


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_pkey PRIMARY KEY (id);


--
-- Name: job_postings job_postings_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.job_postings
    ADD CONSTRAINT job_postings_pkey PRIMARY KEY (id);


--
-- Name: mandrill_messages mandrill_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.mandrill_messages
    ADD CONSTRAINT mandrill_messages_pkey PRIMARY KEY (id);


--
-- Name: migration_mappings migration_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.migration_mappings
    ADD CONSTRAINT migration_mappings_pkey PRIMARY KEY (id);


--
-- Name: newsletter_emails newsletter_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.newsletter_emails
    ADD CONSTRAINT newsletter_emails_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_grants oauth_access_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT oauth_access_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_applications oauth_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT oauth_applications_pkey PRIMARY KEY (id);


--
-- Name: organizer_applications organizer_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.organizer_applications
    ADD CONSTRAINT organizer_applications_pkey PRIMARY KEY (id);


--
-- Name: organizers organizers_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.organizers
    ADD CONSTRAINT organizers_pkey PRIMARY KEY (id);


--
-- Name: participant_clef_tasks participant_clef_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_clef_tasks
    ADD CONSTRAINT participant_clef_tasks_pkey PRIMARY KEY (id);


--
-- Name: participant_organizers participant_organizers_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_organizers
    ADD CONSTRAINT participant_organizers_pkey PRIMARY KEY (id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (id);


--
-- Name: participation_terms participation_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participation_terms
    ADD CONSTRAINT participation_terms_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: reserved_userhandles reserved_userhandles_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.reserved_userhandles
    ADD CONSTRAINT reserved_userhandles_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: submission_file_definitions submission_file_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_file_definitions
    ADD CONSTRAINT submission_file_definitions_pkey PRIMARY KEY (id);


--
-- Name: submission_files submission_files_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_files
    ADD CONSTRAINT submission_files_pkey PRIMARY KEY (id);


--
-- Name: submission_grades submission_grades_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_grades
    ADD CONSTRAINT submission_grades_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: success_stories success_stories_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.success_stories
    ADD CONSTRAINT success_stories_pkey PRIMARY KEY (id);


--
-- Name: task_dataset_file_downloads task_dataset_file_downloads_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.task_dataset_file_downloads
    ADD CONSTRAINT task_dataset_file_downloads_pkey PRIMARY KEY (id);


--
-- Name: task_dataset_files task_dataset_files_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.task_dataset_files
    ADD CONSTRAINT task_dataset_files_pkey PRIMARY KEY (id);


--
-- Name: team_invitations team_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_participants team_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_participants
    ADD CONSTRAINT team_participants_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: user_ratings user_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT user_ratings_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_pkey PRIMARY KEY (id);


--
-- Name: index_active_admin_comments_on_author_type_and_author_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_active_admin_comments_on_author_type_and_author_id ON public.active_admin_comments USING btree (author_type, author_id);


--
-- Name: index_active_admin_comments_on_namespace; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_active_admin_comments_on_namespace ON public.active_admin_comments USING btree (namespace);


--
-- Name: index_active_admin_comments_on_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_active_admin_comments_on_resource_type_and_resource_id ON public.active_admin_comments USING btree (resource_type, resource_id);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_ahoy_events_on_name_and_time; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_ahoy_events_on_name_and_time ON public.ahoy_events USING btree (name, "time");


--
-- Name: index_ahoy_events_on_properties; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_ahoy_events_on_properties ON public.ahoy_events USING gin (properties jsonb_path_ops);


--
-- Name: index_ahoy_events_on_user_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_ahoy_events_on_user_id ON public.ahoy_events USING btree (user_id);


--
-- Name: index_ahoy_events_on_visit_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_ahoy_events_on_visit_id ON public.ahoy_events USING btree (visit_id);


--
-- Name: index_ahoy_visits_on_user_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_ahoy_visits_on_user_id ON public.ahoy_visits USING btree (user_id);


--
-- Name: index_ahoy_visits_on_visit_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_ahoy_visits_on_visit_token ON public.ahoy_visits USING btree (visit_token);


--
-- Name: index_aicrowd_badges_on_badges_event_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_aicrowd_badges_on_badges_event_id ON public.aicrowd_badges USING btree (badges_event_id);


--
-- Name: index_aicrowd_badges_on_name; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_aicrowd_badges_on_name ON public.aicrowd_badges USING btree (name);


--
-- Name: index_aicrowd_user_badges_on_aicrowd_badge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_aicrowd_user_badges_on_aicrowd_badge_id ON public.aicrowd_user_badges USING btree (aicrowd_badge_id);


--
-- Name: index_aicrowd_user_badges_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_aicrowd_user_badges_on_participant_id ON public.aicrowd_user_badges USING btree (participant_id);


--
-- Name: index_badges_events_on_name; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_badges_events_on_name ON public.badges_events USING btree (name);


--
-- Name: index_base_leaderboards_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_base_leaderboards_on_challenge_id ON public.base_leaderboards USING btree (challenge_id);


--
-- Name: index_base_leaderboards_on_challenge_round_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_base_leaderboards_on_challenge_round_id ON public.base_leaderboards USING btree (challenge_round_id);


--
-- Name: index_base_leaderboards_on_leaderboard_type_cd; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_base_leaderboards_on_leaderboard_type_cd ON public.base_leaderboards USING btree (leaderboard_type_cd);


--
-- Name: index_base_leaderboards_on_submitter_type_and_submitter_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_base_leaderboards_on_submitter_type_and_submitter_id ON public.base_leaderboards USING btree (submitter_type, submitter_id);


--
-- Name: index_blazer_audits_on_query_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_audits_on_query_id ON public.blazer_audits USING btree (query_id);


--
-- Name: index_blazer_audits_on_user_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_audits_on_user_id ON public.blazer_audits USING btree (user_id);


--
-- Name: index_blazer_checks_on_creator_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_checks_on_creator_id ON public.blazer_checks USING btree (creator_id);


--
-- Name: index_blazer_checks_on_query_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_checks_on_query_id ON public.blazer_checks USING btree (query_id);


--
-- Name: index_blazer_dashboard_queries_on_dashboard_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_dashboard_queries_on_dashboard_id ON public.blazer_dashboard_queries USING btree (dashboard_id);


--
-- Name: index_blazer_dashboard_queries_on_query_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_dashboard_queries_on_query_id ON public.blazer_dashboard_queries USING btree (query_id);


--
-- Name: index_blazer_dashboards_on_creator_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_dashboards_on_creator_id ON public.blazer_dashboards USING btree (creator_id);


--
-- Name: index_blazer_queries_on_creator_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blazer_queries_on_creator_id ON public.blazer_queries USING btree (creator_id);


--
-- Name: index_blogs_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_blogs_on_participant_id ON public.blogs USING btree (participant_id);


--
-- Name: index_categories_on_name; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_categories_on_name ON public.categories USING btree (name);


--
-- Name: index_category_challenges_on_category_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_category_challenges_on_category_id ON public.category_challenges USING btree (category_id);


--
-- Name: index_category_challenges_on_category_id_and_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_category_challenges_on_category_id_and_challenge_id ON public.category_challenges USING btree (category_id, challenge_id);


--
-- Name: index_category_challenges_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_category_challenges_on_challenge_id ON public.category_challenges USING btree (challenge_id);


--
-- Name: index_challenge_call_responses_on_challenge_call_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_call_responses_on_challenge_call_id ON public.challenge_call_responses USING btree (challenge_call_id);


--
-- Name: index_challenge_calls_on_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_calls_on_organizer_id ON public.challenge_calls USING btree (organizer_id);


--
-- Name: index_challenge_participants_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_participants_on_challenge_id ON public.challenge_participants USING btree (challenge_id);


--
-- Name: index_challenge_participants_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_participants_on_participant_id ON public.challenge_participants USING btree (participant_id);


--
-- Name: index_challenge_partners_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_partners_on_challenge_id ON public.challenge_partners USING btree (challenge_id);


--
-- Name: index_challenge_rounds_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_rounds_on_challenge_id ON public.challenge_rounds USING btree (challenge_id);


--
-- Name: index_challenge_rules_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenge_rules_on_challenge_id ON public.challenge_rules USING btree (challenge_id);


--
-- Name: index_challenges_on_clef_task_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenges_on_clef_task_id ON public.challenges USING btree (clef_task_id);


--
-- Name: index_challenges_on_slug; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_challenges_on_slug ON public.challenges USING btree (slug);


--
-- Name: index_challenges_organizers_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenges_organizers_on_challenge_id ON public.challenges_organizers USING btree (challenge_id);


--
-- Name: index_challenges_organizers_on_challenge_id_and_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_challenges_organizers_on_challenge_id_and_organizer_id ON public.challenges_organizers USING btree (challenge_id, organizer_id);


--
-- Name: index_challenges_organizers_on_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_challenges_organizers_on_organizer_id ON public.challenges_organizers USING btree (organizer_id);


--
-- Name: index_ckeditor_assets_on_type; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_ckeditor_assets_on_type ON public.ckeditor_assets USING btree (type);


--
-- Name: index_clef_tasks_on_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_clef_tasks_on_organizer_id ON public.clef_tasks USING btree (organizer_id);


--
-- Name: index_dataset_file_downloads_on_dataset_file_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_dataset_file_downloads_on_dataset_file_id ON public.dataset_file_downloads USING btree (dataset_file_id);


--
-- Name: index_dataset_file_downloads_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_dataset_file_downloads_on_participant_id ON public.dataset_file_downloads USING btree (participant_id);


--
-- Name: index_dataset_files_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_dataset_files_on_challenge_id ON public.dataset_files USING btree (challenge_id);


--
-- Name: index_dataset_folders_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_dataset_folders_on_challenge_id ON public.dataset_folders USING btree (challenge_id);


--
-- Name: index_disentanglement_leaderboards_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_disentanglement_leaderboards_on_challenge_id ON public.disentanglement_leaderboards USING btree (challenge_id);


--
-- Name: index_disentanglement_leaderboards_on_challenge_round_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_disentanglement_leaderboards_on_challenge_round_id ON public.disentanglement_leaderboards USING btree (challenge_round_id);


--
-- Name: index_disentanglement_leaderboards_on_leaderboard_type_cd; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_disentanglement_leaderboards_on_leaderboard_type_cd ON public.disentanglement_leaderboards USING btree (leaderboard_type_cd);


--
-- Name: index_disentanglement_leaderboards_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_disentanglement_leaderboards_on_participant_id ON public.disentanglement_leaderboards USING btree (participant_id);


--
-- Name: index_email_invitations_on_claimant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_email_invitations_on_claimant_id ON public.email_invitations USING btree (claimant_id);


--
-- Name: index_email_invitations_on_email; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_email_invitations_on_email ON public.email_invitations USING btree (email);


--
-- Name: index_email_invitations_on_invitor_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_email_invitations_on_invitor_id ON public.email_invitations USING btree (invitor_id);


--
-- Name: index_email_invitations_on_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_email_invitations_on_token ON public.email_invitations USING btree (token);


--
-- Name: index_email_preferences_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_email_preferences_on_participant_id ON public.email_preferences USING btree (participant_id);


--
-- Name: index_email_preferences_tokens_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_email_preferences_tokens_on_participant_id ON public.email_preferences_tokens USING btree (participant_id);


--
-- Name: index_follows_on_followable_id_and_followable_type; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_follows_on_followable_id_and_followable_type ON public.follows USING btree (followable_id, followable_type);


--
-- Name: index_follows_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_follows_on_participant_id ON public.follows USING btree (participant_id);


--
-- Name: index_friendly_id_slugs_on_slug_and_sluggable_type; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_friendly_id_slugs_on_slug_and_sluggable_type ON public.friendly_id_slugs USING btree (slug, sluggable_type);


--
-- Name: index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope ON public.friendly_id_slugs USING btree (slug, sluggable_type, scope);


--
-- Name: index_friendly_id_slugs_on_sluggable_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_friendly_id_slugs_on_sluggable_id ON public.friendly_id_slugs USING btree (sluggable_id);


--
-- Name: index_friendly_id_slugs_on_sluggable_type; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_friendly_id_slugs_on_sluggable_type ON public.friendly_id_slugs USING btree (sluggable_type);


--
-- Name: index_invitations_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_invitations_on_challenge_id ON public.invitations USING btree (challenge_id);


--
-- Name: index_invitations_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_invitations_on_participant_id ON public.invitations USING btree (participant_id);


--
-- Name: index_newsletter_emails_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_newsletter_emails_on_challenge_id ON public.newsletter_emails USING btree (challenge_id);


--
-- Name: index_newsletter_emails_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_newsletter_emails_on_participant_id ON public.newsletter_emails USING btree (participant_id);


--
-- Name: index_notifications_on_notifiable_type_and_notifiable_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_notifications_on_notifiable_type_and_notifiable_id ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: index_notifications_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_notifications_on_participant_id ON public.notifications USING btree (participant_id);


--
-- Name: index_oauth_access_grants_on_application_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_oauth_access_grants_on_application_id ON public.oauth_access_grants USING btree (application_id);


--
-- Name: index_oauth_access_grants_on_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_oauth_access_grants_on_token ON public.oauth_access_grants USING btree (token);


--
-- Name: index_oauth_access_tokens_on_application_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_oauth_access_tokens_on_application_id ON public.oauth_access_tokens USING btree (application_id);


--
-- Name: index_oauth_access_tokens_on_refresh_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_refresh_token ON public.oauth_access_tokens USING btree (refresh_token);


--
-- Name: index_oauth_access_tokens_on_resource_owner_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_oauth_access_tokens_on_resource_owner_id ON public.oauth_access_tokens USING btree (resource_owner_id);


--
-- Name: index_oauth_access_tokens_on_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_token ON public.oauth_access_tokens USING btree (token);


--
-- Name: index_oauth_applications_on_uid; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_oauth_applications_on_uid ON public.oauth_applications USING btree (uid);


--
-- Name: index_organizers_on_slug; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_organizers_on_slug ON public.organizers USING btree (slug);


--
-- Name: index_participant_clef_tasks_on_clef_task_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_participant_clef_tasks_on_clef_task_id ON public.participant_clef_tasks USING btree (clef_task_id);


--
-- Name: index_participant_clef_tasks_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_participant_clef_tasks_on_participant_id ON public.participant_clef_tasks USING btree (participant_id);


--
-- Name: index_participant_organizers_on_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_participant_organizers_on_organizer_id ON public.participant_organizers USING btree (organizer_id);


--
-- Name: index_participant_organizers_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_participant_organizers_on_participant_id ON public.participant_organizers USING btree (participant_id);


--
-- Name: index_participant_organizers_on_participant_id_and_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_participant_organizers_on_participant_id_and_organizer_id ON public.participant_organizers USING btree (participant_id, organizer_id);


--
-- Name: index_participants_on_confirmation_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_participants_on_confirmation_token ON public.participants USING btree (confirmation_token);


--
-- Name: index_participants_on_email; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_participants_on_email ON public.participants USING btree (email);


--
-- Name: index_participants_on_reset_password_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_participants_on_reset_password_token ON public.participants USING btree (reset_password_token);


--
-- Name: index_participants_on_slug; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_participants_on_slug ON public.participants USING btree (slug);


--
-- Name: index_participants_on_unlock_token; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_participants_on_unlock_token ON public.participants USING btree (unlock_token);


--
-- Name: index_partners_on_organizer_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_partners_on_organizer_id ON public.partners USING btree (organizer_id);


--
-- Name: index_reserved_userhandles_on_name; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_reserved_userhandles_on_name ON public.reserved_userhandles USING btree (name);


--
-- Name: index_submission_file_definitions_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_submission_file_definitions_on_challenge_id ON public.submission_file_definitions USING btree (challenge_id);


--
-- Name: index_submission_files_on_submission_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_submission_files_on_submission_id ON public.submission_files USING btree (submission_id);


--
-- Name: index_submission_grades_on_slug; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_submission_grades_on_slug ON public.submission_grades USING btree (slug);


--
-- Name: index_submission_grades_on_submission_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_submission_grades_on_submission_id ON public.submission_grades USING btree (submission_id);


--
-- Name: index_submissions_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_submissions_on_challenge_id ON public.submissions USING btree (challenge_id);


--
-- Name: index_submissions_on_challenge_round_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_submissions_on_challenge_round_id ON public.submissions USING btree (challenge_round_id);


--
-- Name: index_submissions_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_submissions_on_participant_id ON public.submissions USING btree (participant_id);


--
-- Name: index_task_dataset_file_downloads_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_task_dataset_file_downloads_on_participant_id ON public.task_dataset_file_downloads USING btree (participant_id);


--
-- Name: index_task_dataset_file_downloads_on_task_dataset_file_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_task_dataset_file_downloads_on_task_dataset_file_id ON public.task_dataset_file_downloads USING btree (task_dataset_file_id);


--
-- Name: index_task_dataset_files_on_clef_task_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_task_dataset_files_on_clef_task_id ON public.task_dataset_files USING btree (clef_task_id);


--
-- Name: index_team_invitations_on_invitee_type_and_invitee_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_team_invitations_on_invitee_type_and_invitee_id ON public.team_invitations USING btree (invitee_type, invitee_id) WHERE ((invitee_type)::text = 'EmailInvitation'::text);


--
-- Name: index_team_invitations_on_invitor_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_team_invitations_on_invitor_id ON public.team_invitations USING btree (invitor_id);


--
-- Name: index_team_invitations_on_team_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_team_invitations_on_team_id ON public.team_invitations USING btree (team_id);


--
-- Name: index_team_invitations_on_uuid; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_team_invitations_on_uuid ON public.team_invitations USING btree (uuid);


--
-- Name: index_team_members_on_name; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_team_members_on_name ON public.team_members USING btree (name);


--
-- Name: index_team_members_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_team_members_on_participant_id ON public.team_members USING btree (participant_id);


--
-- Name: index_team_participants_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_team_participants_on_participant_id ON public.team_participants USING btree (participant_id);


--
-- Name: index_team_participants_on_participant_id_and_team_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_team_participants_on_participant_id_and_team_id ON public.team_participants USING btree (participant_id, team_id);


--
-- Name: index_team_participants_on_team_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_team_participants_on_team_id ON public.team_participants USING btree (team_id);


--
-- Name: index_teams_on_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_teams_on_challenge_id ON public.teams USING btree (challenge_id);


--
-- Name: index_teams_on_name_and_challenge_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE UNIQUE INDEX index_teams_on_name_and_challenge_id ON public.teams USING btree (name, challenge_id);


--
-- Name: index_user_ratings_on_challenge_round_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_user_ratings_on_challenge_round_id ON public.user_ratings USING btree (challenge_round_id);


--
-- Name: index_user_ratings_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_user_ratings_on_participant_id ON public.user_ratings USING btree (participant_id);


--
-- Name: index_versions_on_item_type_and_item_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_versions_on_item_type_and_item_id ON public.versions USING btree (item_type, item_id);


--
-- Name: index_votes_on_participant_id; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_votes_on_participant_id ON public.votes USING btree (participant_id);


--
-- Name: index_votes_on_votable_id_and_votable_type; Type: INDEX; Schema: public; Owner: nick_nack
--

CREATE INDEX index_votes_on_votable_id_and_votable_type ON public.votes USING btree (votable_id, votable_type);


--
-- Name: participant_organizers fk_rails_03369fc7b5; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_organizers
    ADD CONSTRAINT fk_rails_03369fc7b5 FOREIGN KEY (organizer_id) REFERENCES public.organizers(id);


--
-- Name: follows fk_rails_083110362d; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT fk_rails_083110362d FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: submissions fk_rails_182329c489; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT fk_rails_182329c489 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: user_ratings fk_rails_1e202d5657; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT fk_rails_1e202d5657 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: teams fk_rails_2383cb727e; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT fk_rails_2383cb727e FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: dataset_folders fk_rails_2be18a06f4; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_folders
    ADD CONSTRAINT fk_rails_2be18a06f4 FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: email_invitations fk_rails_2d3231727e; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_invitations
    ADD CONSTRAINT fk_rails_2d3231727e FOREIGN KEY (invitor_id) REFERENCES public.participants(id);


--
-- Name: team_members fk_rails_388325a903; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT fk_rails_388325a903 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: challenge_partners fk_rails_3d7aaf3ff9; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_partners
    ADD CONSTRAINT fk_rails_3d7aaf3ff9 FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: base_leaderboards fk_rails_3fd0c70c35; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.base_leaderboards
    ADD CONSTRAINT fk_rails_3fd0c70c35 FOREIGN KEY (challenge_round_id) REFERENCES public.challenge_rounds(id);


--
-- Name: aicrowd_badges fk_rails_41f19fb981; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_badges
    ADD CONSTRAINT fk_rails_41f19fb981 FOREIGN KEY (badges_event_id) REFERENCES public.badges_events(id);


--
-- Name: base_leaderboards fk_rails_44e759267b; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.base_leaderboards
    ADD CONSTRAINT fk_rails_44e759267b FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: challenge_rounds fk_rails_58f957502d; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_rounds
    ADD CONSTRAINT fk_rails_58f957502d FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: challenges_organizers fk_rails_5d49888bd8; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenges_organizers
    ADD CONSTRAINT fk_rails_5d49888bd8 FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: submissions fk_rails_62fce1582b; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT fk_rails_62fce1582b FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: email_preferences fk_rails_6712e930b2; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT fk_rails_6712e930b2 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: participant_clef_tasks fk_rails_6b197e3111; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_clef_tasks
    ADD CONSTRAINT fk_rails_6b197e3111 FOREIGN KEY (clef_task_id) REFERENCES public.clef_tasks(id);


--
-- Name: oauth_access_tokens fk_rails_732cb83ab7; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT fk_rails_732cb83ab7 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: clef_tasks fk_rails_7660c1d17b; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.clef_tasks
    ADD CONSTRAINT fk_rails_7660c1d17b FOREIGN KEY (organizer_id) REFERENCES public.organizers(id);


--
-- Name: aicrowd_user_badges fk_rails_77af53030f; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_user_badges
    ADD CONSTRAINT fk_rails_77af53030f FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: votes fk_rails_7d535390f0; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT fk_rails_7d535390f0 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: newsletter_emails fk_rails_7f61689116; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.newsletter_emails
    ADD CONSTRAINT fk_rails_7f61689116 FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: challenge_participants fk_rails_7fd31647c0; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_participants
    ADD CONSTRAINT fk_rails_7fd31647c0 FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: submission_grades fk_rails_8198fbcfd9; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_grades
    ADD CONSTRAINT fk_rails_8198fbcfd9 FOREIGN KEY (submission_id) REFERENCES public.submissions(id);


--
-- Name: user_ratings fk_rails_8c2dc2ca20; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.user_ratings
    ADD CONSTRAINT fk_rails_8c2dc2ca20 FOREIGN KEY (challenge_round_id) REFERENCES public.challenge_rounds(id);


--
-- Name: newsletter_emails fk_rails_936c62f77e; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.newsletter_emails
    ADD CONSTRAINT fk_rails_936c62f77e FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: dataset_file_downloads fk_rails_9eb5d4b472; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_file_downloads
    ADD CONSTRAINT fk_rails_9eb5d4b472 FOREIGN KEY (dataset_file_id) REFERENCES public.dataset_files(id);


--
-- Name: team_participants fk_rails_9eba5efb2c; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_participants
    ADD CONSTRAINT fk_rails_9eba5efb2c FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: challenge_call_responses fk_rails_a24ea39882; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_call_responses
    ADD CONSTRAINT fk_rails_a24ea39882 FOREIGN KEY (challenge_call_id) REFERENCES public.challenge_calls(id);


--
-- Name: invitations fk_rails_a4a4e9d2a4; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT fk_rails_a4a4e9d2a4 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: team_invitations fk_rails_a644ec9317; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT fk_rails_a644ec9317 FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: submission_file_definitions fk_rails_a801f5516c; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_file_definitions
    ADD CONSTRAINT fk_rails_a801f5516c FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: participant_organizers fk_rails_ab56443283; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_organizers
    ADD CONSTRAINT fk_rails_ab56443283 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: partners fk_rails_ac4a29ffd1; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT fk_rails_ac4a29ffd1 FOREIGN KEY (organizer_id) REFERENCES public.organizers(id);


--
-- Name: oauth_access_grants fk_rails_b4b53e07b8; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT fk_rails_b4b53e07b8 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: challenges_organizers fk_rails_bd70e565f6; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenges_organizers
    ADD CONSTRAINT fk_rails_bd70e565f6 FOREIGN KEY (organizer_id) REFERENCES public.organizers(id);


--
-- Name: invitations fk_rails_c2309c24bd; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT fk_rails_c2309c24bd FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: dataset_file_downloads fk_rails_c485aee385; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.dataset_file_downloads
    ADD CONSTRAINT fk_rails_c485aee385 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: submission_files fk_rails_d1aca45f2f; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.submission_files
    ADD CONSTRAINT fk_rails_d1aca45f2f FOREIGN KEY (submission_id) REFERENCES public.submissions(id);


--
-- Name: aicrowd_user_badges fk_rails_d5697d92f3; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.aicrowd_user_badges
    ADD CONSTRAINT fk_rails_d5697d92f3 FOREIGN KEY (aicrowd_badge_id) REFERENCES public.aicrowd_badges(id);


--
-- Name: team_invitations fk_rails_d8157fda05; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT fk_rails_d8157fda05 FOREIGN KEY (invitor_id) REFERENCES public.participants(id);


--
-- Name: challenge_participants fk_rails_d8df5b8654; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_participants
    ADD CONSTRAINT fk_rails_d8df5b8654 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: participant_clef_tasks fk_rails_e84c24dfaa; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.participant_clef_tasks
    ADD CONSTRAINT fk_rails_e84c24dfaa FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: email_invitations fk_rails_efbfd7d722; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.email_invitations
    ADD CONSTRAINT fk_rails_efbfd7d722 FOREIGN KEY (claimant_id) REFERENCES public.participants(id);


--
-- Name: task_dataset_files fk_rails_f90572ee46; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.task_dataset_files
    ADD CONSTRAINT fk_rails_f90572ee46 FOREIGN KEY (clef_task_id) REFERENCES public.clef_tasks(id);


--
-- Name: blogs fk_rails_f9e0464b78; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.blogs
    ADD CONSTRAINT fk_rails_f9e0464b78 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: team_participants fk_rails_fd31fcf220; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.team_participants
    ADD CONSTRAINT fk_rails_fd31fcf220 FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: challenge_rules fk_rails_fd46450b06; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.challenge_rules
    ADD CONSTRAINT fk_rails_fd46450b06 FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: notifications fk_rails_fea941547a; Type: FK CONSTRAINT; Schema: public; Owner: nick_nack
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_fea941547a FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- PostgreSQL database dump complete
--

